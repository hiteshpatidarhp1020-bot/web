/* ==========================================================================
   PRISMA AI — INDUSTRIES PAGE INTERACTIVITY & ANIMATIONS (INDEX3 SYSTEM)
   Vanilla JS + GSAP 3 + ScrollTrigger
   ========================================================================== */

(function () {
  'use strict';

  const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  /* ------------------------------------------------------------------------
     1. ALL 7 ORIGINAL INDUSTRIES FROM https://www.prisma.ai/industries
     ------------------------------------------------------------------------ */
  const SECTORS = [
    {
      key: 'banking',
      code: 'SECTOR 01 // BANKING & FINANCE',
      name: 'Banking & Finance',
      img: 'assets/img/industries/banking.png',
      alt: 'AI in Banking and Finance',
      caps: [
        'Face recognition based financial transactions',
        'Illegal object detection',
        'Suspicious behaviour alert',
        'Identification of lost bag',
        'Tracking of attendance',
        'Providing assistance to elderly'
      ]
    },
    {
      key: 'aviation',
      code: 'SECTOR 02 // AVIATION',
      name: 'Aviation',
      img: 'assets/img/industries/aviation.jpg',
      alt: 'AI in Aviation Industry',
      caps: [
        'Providing assistance to special individuals',
        'Face-as-boarding pass for access',
        'Providing assistance to elderly',
        'Identification of lost bag',
        'Alert for unattended bag/ purse'
      ]
    },
    {
      key: 'infrastructure',
      code: 'SECTOR 03 // INFRASTRUCTURE',
      name: 'Infrastructure',
      img: 'assets/img/industries/infrastructure.jpg',
      alt: 'AI Solutions for Infrastructure',
      caps: [
        'Ticketing for red light violations',
        'Ticketing for reckless driving',
        'Alert on accident',
        'Toll collection through license plate',
        'Ticketing for speed violation'
      ]
    },
    {
      key: 'security',
      code: 'SECTOR 04 // SECURITY',
      name: 'Security',
      img: 'assets/img/industries/security.jpg',
      alt: 'AI in Security',
      caps: [
        'Incident detection in crowd',
        'Crowd sentiment analysis',
        'Hazardous object detection',
        'Facial authentication for entry',
        'Banned person alert',
        'Suspicious behavior alert'
      ]
    },
    {
      key: 'education',
      code: 'SECTOR 05 // EDUCATION',
      name: 'Education',
      img: 'assets/img/industries/education.jpg',
      alt: 'AI in Education Sector',
      caps: [
        'Suspicious activity - body movements',
        'Suspicious activity - eye movements',
        'Sentiment analysis',
        'Detection of banned objects',
        'Tracking of attendance',
        'Automated paper corrections'
      ]
    },
    {
      key: 'events',
      code: 'SECTOR 06 // EVENTS',
      name: 'Events',
      img: 'assets/img/industries/events.jpg',
      alt: 'AI in Events',
      caps: [
        'Incident detection in crowd',
        'Crowd sentiment analysis',
        'Parking management system',
        'Face-as-a-ticket for entry',
        'Crowd density analysis',
        'Hazardous object detection'
      ]
    },
    {
      key: 'manufacturing',
      code: 'SECTOR 07 // MANUFACTURING',
      name: 'Manufacturing',
      img: 'assets/img/industries/manufacturing.jpg',
      alt: 'AI in Manufacturing Industry',
      caps: [
        'Face recognition for entry',
        'Tracking of attendance',
        'Detection of safety gear',
        'Predictive maintenance',
        'Alert on defect detection'
      ]
    }
  ];

  /* ------------------------------------------------------------------------
     2. INTERACTIVE SPLIT SPOTLIGHT CONTROLLER
     ------------------------------------------------------------------------ */
  const rail = document.getElementById('v3SectorRail');
  const spotPanel = document.getElementById('v3SpotlightPanel');
  const spotImg = document.getElementById('v3SpotImg');
  const spotCode = document.getElementById('v3SpotCode');
  const spotTitle = document.getElementById('v3SpotTitle');
  const spotCaps = document.getElementById('v3SpotCaps');
  const spotDemoBtn = document.getElementById('v3SpotDemoBtn');
  const sectorSelect = document.getElementById('v3SectorSelect');

  function selectSector(idx, animate) {
    const s = SECTORS[idx];
    if (!s) return;

    if (rail) {
      rail.querySelectorAll('.v3-sector-rail-btn').forEach((btn, i) => {
        const isAct = i === idx;
        btn.classList.toggle('active', isAct);
        btn.setAttribute('aria-selected', isAct ? 'true' : 'false');
      });
    }

    if (animate && spotPanel && !prefersReducedMotion && typeof gsap !== 'undefined') {
      gsap.fromTo(spotPanel, { opacity: 0.72, y: 8 }, { opacity: 1, y: 0, duration: 0.34, ease: 'power2.out' });
    }

    if (spotImg) {
      spotImg.src = s.img;
      spotImg.alt = s.alt;
    }
    if (spotCode) spotCode.textContent = s.code;
    if (spotTitle) spotTitle.textContent = s.name;
    if (spotCaps) {
      spotCaps.innerHTML = s.caps
        .map((c) => `<div class="v3-cap-item"><i class="bi bi-check2"></i> ${c}</div>`)
        .join('');
    }
    if (spotDemoBtn) {
      spotDemoBtn.dataset.indDemo = s.name;
    }
  }

  function buildSectorRail() {
    if (!rail) return;
    rail.innerHTML = SECTORS.map(
      (s, i) => `
      <button type="button" class="v3-sector-rail-btn${i === 0 ? ' active' : ''}" role="tab" aria-selected="${i === 0 ? 'true' : 'false'}" data-sector-idx="${i}">
        <span class="v3-sector-rail-name">${s.name}</span>
        <span class="v3-sector-rail-count">${s.caps.length}+ APIs</span>
      </button>`
    ).join('');

    rail.querySelectorAll('.v3-sector-rail-btn').forEach((btn) => {
      btn.addEventListener('click', () => selectSector(Number(btn.dataset.sectorIdx), true));
    });

    selectSector(0, false);
  }

  // Pre-fill demo sector dropdown when clicking any sector CTA
  document.addEventListener('click', (e) => {
    const trigger = e.target.closest('[data-ind-demo]');
    if (trigger && sectorSelect) {
      sectorSelect.value = trigger.dataset.indDemo;
    }
  });

  /* ------------------------------------------------------------------------
     3. DEMO FORM & NEWSLETTER VALIDATION
     ------------------------------------------------------------------------ */
  const demoForm = document.getElementById('v3DemoForm');
  const demoOk = document.getElementById('v3DemoOk');
  if (demoForm) {
    demoForm.addEventListener('submit', (e) => {
      e.preventDefault();
      if (!demoForm.checkValidity()) {
        demoForm.classList.add('was-validated');
        return;
      }
      if (demoOk) demoOk.classList.remove('d-none');
      demoForm.classList.remove('was-validated');
      demoForm.reset();
    });
  }

  const newsForm = document.getElementById('v3NewsletterForm');
  const newsOk = document.getElementById('v3NewsOk');
  if (newsForm) {
    newsForm.addEventListener('submit', (e) => {
      e.preventDefault();
      if (newsOk) newsOk.classList.remove('d-none');
      newsForm.reset();
    });
  }

  /* ------------------------------------------------------------------------
     4. EXACT SAME GSAP + SCROLLTRIGGER ANIMATIONS AS index3.html
     ------------------------------------------------------------------------ */
  function splitWordsForReveal() {
    document.querySelectorAll('[data-word-reveal]').forEach((heading) => {
      const text = heading.textContent.trim();
      const words = text.split(/\s+/);
      heading.innerHTML = words.map((w) => `<span class="wr-word">${w}</span>`).join(' ');
    });
  }

  function initScrollAnimations() {
    if (typeof gsap === 'undefined' || typeof ScrollTrigger === 'undefined' || prefersReducedMotion) {
      return;
    }

    gsap.registerPlugin(ScrollTrigger);

    // Hero Stagger Entrance
    gsap.from('.v3-hero-stagger', {
      y: 26,
      opacity: 0,
      duration: 0.72,
      stagger: 0.1,
      ease: 'power3.out'
    });

    // Word-by-word Luminance Reveals (Dark & Light Sections)
    document.querySelectorAll('[data-word-reveal]').forEach((heading) => {
      const mode = heading.dataset.wordReveal;
      const words = heading.querySelectorAll('.wr-word');
      if (!words.length) return;

      const isHero = heading.closest('#hero-industries') !== null;

      if (isHero) {
        gsap.fromTo(
          words,
          { color: 'rgba(255,255,255,0.2)', y: 14 },
          { color: '#ffffff', y: 0, duration: 0.7, stagger: 0.08, ease: 'power3.out' }
        );
      } else {
        gsap.fromTo(
          words,
          { color: mode === 'dark' ? 'rgba(255,255,255,0.2)' : '#d1d5dc', y: 12 },
          {
            color: mode === 'dark' ? '#ffffff' : '#0a0a0e',
            y: 0,
            stagger: 0.08,
            ease: 'power2.out',
            scrollTrigger: {
              trigger: heading,
              start: 'top 84%',
              end: 'top 44%',
              scrub: 0.6
            }
          }
        );
      }
    });

    // Standard Section & Editorial Strip Reveals
    gsap.utils.toArray('.v3-reveal').forEach((el) => {
      gsap.from(el, {
        y: 30,
        opacity: 0,
        duration: 0.78,
        ease: 'power3.out',
        scrollTrigger: { trigger: el, start: 'top 86%', once: true }
      });
    });

    // Staggered Grids & Cards
    document.querySelectorAll('.row').forEach((row) => {
      const items = row.querySelectorAll(':scope > .v3-stagger');
      if (!items.length) return;
      gsap.from(items, {
        y: 28,
        opacity: 0,
        duration: 0.7,
        stagger: 0.08,
        ease: 'power3.out',
        scrollTrigger: { trigger: row, start: 'top 86%', once: true }
      });
    });
  }

  window.addEventListener('load', () => {
    buildSectorRail();
    splitWordsForReveal();
    initScrollAnimations();
    if (document.fonts && document.fonts.ready && typeof ScrollTrigger !== 'undefined') {
      document.fonts.ready.then(() => ScrollTrigger.refresh());
    }
  });
})();
