/* ==========================================================================
   PRISMA AI — GLOBAL PRODUCTS MEGA-DROPDOWN & SHARED ANIMATION ENGINE
   Used across index3.html, about3.html, core-algorithm.html, industries.html,
   gryfas.html, gryscan.html, grysec.html, veri5.html, and contact.html
   ========================================================================== */

(function () {
  'use strict';

  const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  /* ------------------------------------------------------------------------
     1. PRODUCTS MEGA-MENU DROPDOWN (DESKTOP HOVER + CLICK + OUTSIDE CLOSE)
     ------------------------------------------------------------------------ */
  function initMegaDropdowns() {
    const dropdowns = document.querySelectorAll('.v3-nav-dropdown');
    if (!dropdowns.length) return;

    dropdowns.forEach((dd) => {
      const trigger = dd.querySelector('.v3-nav-drop-trigger');
      let closeTimer = null;

      function openMenu() {
        clearTimeout(closeTimer);
        dropdowns.forEach((other) => {
          if (other !== dd) {
            other.classList.remove('is-open');
            const ot = other.querySelector('.v3-nav-drop-trigger');
            if (ot) ot.setAttribute('aria-expanded', 'false');
          }
        });
        dd.classList.add('is-open');
        if (trigger) trigger.setAttribute('aria-expanded', 'true');
      }

      function scheduleClose() {
        clearTimeout(closeTimer);
        closeTimer = setTimeout(() => {
          dd.classList.remove('is-open');
          if (trigger) trigger.setAttribute('aria-expanded', 'false');
        }, 220);
      }

      // Desktop hover
      dd.addEventListener('mouseenter', () => {
        if (window.innerWidth >= 992) openMenu();
      });
      dd.addEventListener('mouseleave', () => {
        if (window.innerWidth >= 992) scheduleClose();
      });

      // Click toggle
      if (trigger) {
        trigger.addEventListener('click', (e) => {
          e.preventDefault();
          e.stopPropagation();
          if (dd.classList.contains('is-open')) {
            dd.classList.remove('is-open');
            trigger.setAttribute('aria-expanded', 'false');
          } else {
            openMenu();
          }
        });
      }

      // Close when navigating via link inside mega menu
      dd.querySelectorAll('.v3-mega-menu a').forEach((link) => {
        link.addEventListener('click', () => {
          dd.classList.remove('is-open');
          if (trigger) trigger.setAttribute('aria-expanded', 'false');
        });
      });
    });

    // Close on outside click
    document.addEventListener('click', (e) => {
      if (!e.target.closest('.v3-nav-dropdown')) {
        dropdowns.forEach((dd) => {
          dd.classList.remove('is-open');
          const t = dd.querySelector('.v3-nav-drop-trigger');
          if (t) t.setAttribute('aria-expanded', 'false');
        });
      }
    });

    // Close on Escape key
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') {
        dropdowns.forEach((dd) => {
          dd.classList.remove('is-open');
          const t = dd.querySelector('.v3-nav-drop-trigger');
          if (t) t.setAttribute('aria-expanded', 'false');
        });
      }
    });
  }

  /* ------------------------------------------------------------------------
     2. SHARED SCROLL ANIMATIONS FOR PRODUCT & CONTACT PAGES
     (Runs automatically on pages marked with data-v3-page="subpage")
     ------------------------------------------------------------------------ */
  function initSubpageAnimations() {
    if (document.body.dataset.v3Page !== 'subpage') return;

    // Split word-reveal headings
    document.querySelectorAll('[data-word-reveal]').forEach((heading) => {
      const text = heading.textContent.trim();
      const words = text.split(/\s+/);
      heading.innerHTML = words.map((w) => `<span class="wr-word">${w}</span>`).join(' ');
    });

    if (typeof gsap === 'undefined' || typeof ScrollTrigger === 'undefined' || prefersReducedMotion) {
      return;
    }

    gsap.registerPlugin(ScrollTrigger);

    // Hero Stagger
    gsap.from('.v3-hero-stagger', {
      y: 26,
      opacity: 0,
      duration: 0.72,
      stagger: 0.09,
      ease: 'power3.out'
    });

    // Word-by-word Luminance Reveals
    document.querySelectorAll('[data-word-reveal]').forEach((heading) => {
      const mode = heading.dataset.wordReveal;
      const words = heading.querySelectorAll('.wr-word');
      if (!words.length) return;

      const isHero = heading.closest('.v3-hero') !== null;
      if (isHero) {
        gsap.fromTo(
          words,
          { color: 'rgba(255,255,255,0.2)', y: 14 },
          { color: '#ffffff', y: 0, duration: 0.7, stagger: 0.08, ease: 'power3.out' }
        );
      } else {
        gsap.fromTo(
          words,
          { color: mode === 'dark' ? 'rgba(255,255,255,0.2)' : '#d1d5dc', y: 12 },
          {
            color: mode === 'dark' ? '#ffffff' : '#0a0a0e',
            y: 0,
            stagger: 0.08,
            ease: 'power2.out',
            scrollTrigger: {
              trigger: heading,
              start: 'top 84%',
              end: 'top 44%',
              scrub: 0.6
            }
          }
        );
      }
    });

    // Standard Section Reveals
    gsap.utils.toArray('.v3-reveal').forEach((el) => {
      gsap.from(el, {
        y: 30,
        opacity: 0,
        duration: 0.76,
        ease: 'power3.out',
        scrollTrigger: { trigger: el, start: 'top 86%', once: true }
      });
    });

    // Staggered Grids
    document.querySelectorAll('.row').forEach((row) => {
      const items = row.querySelectorAll(':scope > .v3-stagger');
      if (!items.length) return;
      gsap.from(items, {
        y: 28,
        opacity: 0,
        duration: 0.68,
        stagger: 0.075,
        ease: 'power3.out',
        scrollTrigger: { trigger: row, start: 'top 86%', once: true }
      });
    });

    // Veri5 Pinned 8-Layer Console (when present on veri5.html)
    const veri5PinSection = document.getElementById('veri5PinSection');
    const veri5Console = document.getElementById('veri5Console');
    const veri5List = document.getElementById('veri5LayersList');
    if (veri5PinSection && veri5Console && veri5List) {
      const mm = gsap.matchMedia();
      mm.add('(min-width: 992px)', () => {
        ScrollTrigger.create({
          trigger: veri5PinSection,
          start: 'top 108px',
          end: () => '+=' + Math.max(120, veri5List.offsetHeight - veri5Console.offsetHeight),
          pin: veri5Console,
          pinSpacing: false,
          invalidateOnRefresh: true
        });
      });

      const layerCards = document.querySelectorAll('.v3-layer-step-card');
      layerCards.forEach((card) => {
        ScrollTrigger.create({
          trigger: card,
          start: 'top 58%',
          end: 'bottom 42%',
          onEnter: () => card.click(),
          onEnterBack: () => card.click()
        });
      });
    }
  }

  /* ------------------------------------------------------------------------
     3. SHARED DEMO MODAL & NEWSLETTER HANDLER FOR SUBPAGES
     ------------------------------------------------------------------------ */
  function initSubpageForms() {
    if (document.body.dataset.v3Page !== 'subpage') return;

    const demoForm = document.getElementById('v3DemoForm');
    const demoOk = document.getElementById('v3DemoOk');
    if (demoForm) {
      demoForm.addEventListener('submit', (e) => {
        e.preventDefault();
        if (!demoForm.checkValidity()) {
          demoForm.classList.add('was-validated');
          return;
        }
        const name = (document.getElementById('v3Name')?.value || '').trim();
        const company = (document.getElementById('v3Company')?.value || '').trim();
        const email = (document.getElementById('v3Email')?.value || '').trim();
        const phone = (document.getElementById('v3Phone')?.value || '').trim();
        const product = document.getElementById('v3ProdSelect')?.value || 'Prisma AI';

        const subject = encodeURIComponent(`Demo Request: ${product} — ${company}`);
        const body = encodeURIComponent(
          `Hello Prisma AI Team,\n\nI would like to request a demo for ${product}.\n\nName: ${name}\nCompany: ${company}\nEmail: ${email}\nPhone: ${phone}\n\nConsent provided to use my personal data to respond to this query.`
        );
        window.location.href = `mailto:contact@prisma.ai?subject=${subject}&body=${body}`;

        if (demoOk) demoOk.classList.remove('d-none');
        demoForm.classList.remove('was-validated');
      });
    }

    const newsForm = document.getElementById('v3NewsletterForm');
    const newsOk = document.getElementById('v3NewsOk');
    if (newsForm) {
      newsForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const email = newsForm.querySelector('input[type="email"]')?.value || '';
        window.location.href = `mailto:contact@prisma.ai?subject=${encodeURIComponent('Prisma AI Newsletter Subscription')}&body=${encodeURIComponent('Please subscribe ' + email + ' to Prisma AI news and updates.')}`;
        if (newsOk) newsOk.classList.remove('d-none');
        newsForm.reset();
      });
    }
  }

  window.addEventListener('DOMContentLoaded', () => {
    initMegaDropdowns();
    initSubpageForms();
  });

  window.addEventListener('load', () => {
    initSubpageAnimations();
    if (document.fonts && document.fonts.ready && typeof ScrollTrigger !== 'undefined') {
      document.fonts.ready.then(() => ScrollTrigger.refresh());
    }
  });
})();
