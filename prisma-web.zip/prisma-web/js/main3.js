/* ==========================================================================
   PRISMA AI — VERSION 3 LUMINOUS EDGE AI CHOREOGRAPHY
   Vanilla JS + GSAP 3 + ScrollTrigger + 60fps Dotted 3D Globe Canvas
   ========================================================================== */

(function () {
  'use strict';

  const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  /* ------------------------------------------------------------------------
     1. PLAYGROUND & PRODUCT DATA (100% Authentic Prisma AI)
     ------------------------------------------------------------------------ */
  const PLAYGROUND_MODES = {
    face: {
      prompt: 'Run GryFAS active & passive liveness check on ATM camera stream #04',
      output:
        '[ENGINE] GryFAS Biometric Auth • [LIVENESS] Active + Passive Verified (0.00% Spoof) • [ACCURACY] 99.4% • [LATENCY] 14ms On-Premise • [ACTION] Transaction Authorized'
    },
    anpr: {
      prompt: 'Monitor European Highway CCTV Lane 3 for speed violation & toll ANPR',
      output:
        '[ENGINE] Gryphos ANPR OCR • [PLATE] DE-B 4829X • [SPEED] 142 km/h (Violation Flagged) • [TOLL] Auto-Billed • [ACTION] Automated Citation Dispatched'
    },
    bag: {
      prompt: 'Scan Airport Green/Red Channel BSM feed for suspicious unattended bag',
      output:
        '[ENGINE] GrySCAN BSM Module • [ALERT] Unattended Bag Flagged (Zone B4) • [PROFILE] Boarding Pass Linked • [ACTION] Mobile Push Notification Sent to Customs Officer'
    },
    crowd: {
      prompt: 'Count devotee inflow/outflow & watchlist check at Temple Gate No. 2',
      output:
        '[ENGINE] Gryphos Crowd & Face AI • [FLOW] 412/min Optimal Density • [SENTIMENT] Calm • [WATCHLIST] 0 Flagged • [ACTION] Live Dashboard Updated'
    },
    vault: {
      prompt: 'Authenticate administrator face + gesture for Server Room & Bank Vault',
      output:
        '[ENGINE] GrySEC Face Login • [IDENTITY] Verified Authorized Admin • [GESTURE] Secondary Match Confirmed • [ACTION] Vault Door & Server Domain Unlocked'
    },
    veri5: {
      prompt: 'Execute Veri5 8-layer contactless identity verification for airport check-in',
      output:
        '[ENGINE] Veri5 Multi-Factor • [LAYERS] Face + Govt. ID + Liveness + Mobile OTP Passed • [IMPERSONATION] Negated • [ACTION] Face-as-Boarding-Pass Issued'
    }
  };

  const PRODUCT_DETAILS = {
    gryfas: {
      tag: 'FINANCIAL AUTHENTICATION // GRYFAS',
      title: 'GryFAS — Biometric Transaction Security',
      demo: 'GryFAS',
      url: 'gryfas.html',
      desc: 'Surpasses traditional PIN and OTP methods with facial authentication for every transaction, delivering active & passive liveness and anti-spoofing protection.',
      bullets: [
        'Online Banking biometric authorization',
        'ATM Withdrawals with Facial Match + PIN',
        'Active & Passive Liveness + Gesture Match',
        'Anti-Spoof & Real-Time Intrusion Detection',
        'Secure Enterprise Application Login',
        'Seamless Core Banking Integration'
      ]
    },
    gryscan: {
      tag: 'AVIATION & CUSTOMS // GRYSCAN',
      title: 'GrySCAN — Baggage & Passenger Profiling',
      demo: 'GrySCAN',
      url: 'gryscan.html',
      desc: 'Streamlines suspicious bag detection and inline customs decision-making at airports with Green/Red channel profiling, BSM boarding pass linking, and mobile push alerts.',
      bullets: [
        'Suspicious Bag Detection via Gryphos Towers',
        'Passenger Profiling at Baggage Security Module (BSM)',
        'Custom Red Channel Database Integration',
        'Dual-Channel Facial Recognition Capture',
        'Repeat Offender & Loitering Instant Detection',
        'Mobile Push Alerts with Photo, Flight & Seat Info'
      ]
    },
    grysec: {
      tag: 'ACCESS CONTROL // GRYSEC',
      title: 'GrySEC — Server, Vault & Domain Face Login',
      demo: 'GrySEC',
      url: 'grysec.html',
      desc: 'Adds biometric facial and gesture authentication to server environments, bank vaults, and corporate doors while automating employee attendance.',
      bullets: [
        'Critical Server Room Facial Login Layer',
        'Bank Vault Biometric Protection',
        'Domain Access Enhancement Beyond Passwords',
        'Automated Door Opening Control',
        'Streamlined Attendance Management',
        'Real-Time Breach Alerts & Gesture Verification'
      ]
    },
    veri5: {
      tag: '8-LAYER IDENTITY // VERI5',
      title: 'Veri5 — Contactless Identity Verification',
      demo: 'Veri5',
      url: 'veri5.html',
      desc: 'AI-empowered multi-layered identity verification built on Gryphos — accelerating verification cycles, stopping impersonation, and eliminating password risks.',
      bullets: [
        '8 Layers: Email, Mobile, Face, Govt. ID, Captcha, Gesture, Liveness & Live Video Call',
        'Contactless Hotel & Airport Check-In',
        'Face-as-a-Ticket Venue & Event Entry',
        'Official Document & Candidate Verification',
        'Password-less Verification & Authentication',
        'Third-Party Data Validation & Sharing'
      ]
    },
    gryphos: {
      tag: 'CORE COMPUTER VISION ENGINE // GRYPHOS',
      title: 'Gryphos — 230+ Ready-to-Use AI Libraries',
      demo: 'Gryphos Platform',
      url: 'core-algorithm.html',
      desc: 'Prisma AI’s proprietary Deep Convolutional Neural Network & cognitive self-learning platform deployable on-premise or private cloud with a Web Dashboard for every API.',
      bullets: [
        'Face, Object, Image Recognition & High-Speed OCR',
        'Body Pose Estimation & Predictive Behavior Analysis',
        'Assistance for Elderly, Mothers & Special Individuals',
        'Lost Baggage Identification from Video Archives',
        'Supply Chain Box, Pallet & Truck Tracking',
        'Advanced AI X-Ray Prohibited Object Detection'
      ]
    },
    company: {
      tag: 'HERITAGE & RECOGNITION // PRISMA AI',
      title: 'Global Leadership, Awards & 7 Offices',
      demo: 'Gryphos Platform',
      url: 'about3.html',
      desc: 'Founded with German computer vision roots four decades ago and headquartered in Singapore, led by Chairman & Group CEO Dr. Shreeram Iyer, Group COO Amitabh Roy Chowdhury, and CPTO Vinit Jha.',
      bullets: [
        'Great Place To Work® Certified (Apr 2026 – Apr 2027, India)',
        'AsiaOne World’s Greatest Brands & Leaders 2021–22',
        'Hasso Plattner Award Winner in Europe',
        'Nominated Top 10 Future Tech Companies Globally',
        '7 Global Offices: Singapore, Berlin, London, Dubai, Florence, Mumbai & Bengaluru',
        'Trusted by Adani, NPCI, Lufthansa, Air India, Bayer, IKEA & Maharashtra Police'
      ]
    }
  };

  /* ------------------------------------------------------------------------
     2. 00:00 - 00:03 BRAND PRELOADER CURTAIN WIPE
     ------------------------------------------------------------------------ */
  function runPreloader(onComplete) {
    const pre = document.getElementById('v3Preloader');
    const wipe = document.getElementById('v3PreWipe');
    const ring = document.getElementById('v3PreRing');
    const word = document.getElementById('v3PreWord');

    if (!pre || prefersReducedMotion || typeof gsap === 'undefined') {
      if (pre) pre.remove();
      if (wipe) wipe.remove();
      onComplete();
      return;
    }

    const tl = gsap.timeline({
      onComplete: () => {
        pre.remove();
        if (wipe) wipe.remove();
        onComplete();
      }
    });

    tl.fromTo(ring, { scale: 0.72, opacity: 0 }, { scale: 1, opacity: 1, duration: 0.42, ease: 'power3.out' })
      .to(word, { maxWidth: 260, opacity: 1, duration: 0.52, ease: 'power3.out' }, '+=0.08')
      .to(wipe, { height: '100%', duration: 0.48, ease: 'power4.inOut' }, '+=0.2')
      .set(pre, { opacity: 0 })
      .to(wipe, { yPercent: -100, duration: 0.52, ease: 'power4.inOut' });
  }

  /* ------------------------------------------------------------------------
     3. 00:18 - 00:22 GLOWING DOTTED 3D EARTH GLOBE CANVAS
     ------------------------------------------------------------------------ */
  function initDottedGlobe() {
    const canvas = document.getElementById('v3GlobeCanvas');
    if (!canvas) return;
    const ctx = canvas.getContext('2d');

    let size = 500;
    function resize() {
      const rect = canvas.parentElement.getBoundingClientRect();
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      size = Math.min(rect.width || 500, rect.height || 500);
      canvas.width = Math.floor(size * dpr);
      canvas.height = Math.floor(size * dpr);
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    }
    resize();
    window.addEventListener('resize', resize);

    // Lightweight landmass approximation (lat/lon bounding lobes for clean continents)
    function isLand(latDeg, lonDeg) {
      const regions = [
        // Europe
        [36, 68, -10, 42],
        // Asia
        [8, 66, 42, 145],
        // India peninsula emphasis
        [7, 32, 68, 90],
        // SE Asia / Singapore
        [-8, 20, 95, 130],
        // Africa
        [-34, 35, -18, 50],
        // North America
        [15, 68, -140, -58],
        // South America
        [-52, 12, -82, -35],
        // Australia
        [-40, -12, 113, 154]
      ];
      for (const [latMin, latMax, lonMin, lonMax] of regions) {
        if (latDeg >= latMin && latDeg <= latMax && lonDeg >= lonMin && lonDeg <= lonMax) {
          // Organic edge modulation
          const wave = Math.sin(latDeg * 0.23) * Math.cos(lonDeg * 0.17);
          if (wave > -0.62) return true;
        }
      }
      return false;
    }

    // Generate Fibonacci sphere dots
    const dots = [];
    const N = 1450;
    const goldenAngle = Math.PI * (3 - Math.sqrt(5));
    for (let i = 0; i < N; i++) {
      const y = 1 - (i / (N - 1)) * 2;
      const r = Math.sqrt(1 - y * y);
      const theta = goldenAngle * i;
      const x = Math.cos(theta) * r;
      const z = Math.sin(theta) * r;
      const lat = (Math.asin(y) * 180) / Math.PI;
      const lon = (Math.atan2(z, x) * 180) / Math.PI;
      dots.push({ x, y, z, land: isLand(lat, lon) });
    }

    // Real Prisma AI 7 Office Coordinates
    const offices = [
      { name: 'Singapore', lat: 1.35, lon: 103.82 },
      { name: 'Mumbai', lat: 19.08, lon: 72.88 },
      { name: 'Bengaluru', lat: 12.97, lon: 77.59 },
      { name: 'Dubai', lat: 25.2, lon: 55.27 },
      { name: 'Berlin', lat: 52.52, lon: 13.4 },
      { name: 'London', lat: 51.51, lon: -0.13 },
      { name: 'Florence', lat: 43.77, lon: 11.25 }
    ].map((o) => {
      const phi = (o.lat * Math.PI) / 180;
      const lam = (o.lon * Math.PI) / 180;
      return {
        name: o.name,
        x: Math.cos(phi) * Math.cos(lam),
        y: Math.sin(phi),
        z: Math.cos(phi) * Math.sin(lam)
      };
    });

    let rotY = -1.25; // Start facing Asia / Europe / Middle East
    let pulse = 0;
    let isVisible = true;

    if ('IntersectionObserver' in window) {
      const obs = new IntersectionObserver(
        (entries) => {
          isVisible = entries[0].isIntersecting;
        },
        { threshold: 0.01 }
      );
      obs.observe(canvas);
    }

    function draw() {
      requestAnimationFrame(draw);
      if (!isVisible) return;

      ctx.clearRect(0, 0, size, size);
      const cx = size / 2;
      const cy = size / 2;
      const R = size * 0.37;

      // Dark sphere core with subtle inner atmospheric rim
      const sphereGrad = ctx.createRadialGradient(cx - R * 0.25, cy - R * 0.25, R * 0.1, cx, cy, R);
      sphereGrad.addColorStop(0, '#13131b');
      sphereGrad.addColorStop(0.76, '#0a0a10');
      sphereGrad.addColorStop(0.95, 'rgba(255, 110, 42, 0.35)');
      sphereGrad.addColorStop(1, 'rgba(255, 130, 62, 0.72)');

      ctx.beginPath();
      ctx.arc(cx, cy, R, 0, Math.PI * 2);
      ctx.fillStyle = sphereGrad;
      ctx.fill();

      const cosY = Math.cos(rotY);
      const sinY = Math.sin(rotY);
      const tiltX = 0.22;
      const cosX = Math.cos(tiltX);
      const sinX = Math.sin(tiltX);

      // Draw dotted globe
      for (let i = 0; i < dots.length; i++) {
        const d = dots[i];
        const rx = d.x * cosY - d.z * sinY;
        const rz = d.x * sinY + d.z * cosY;
        const ry = d.y * cosX - rz * sinX;
        const fz = d.y * sinX + rz * cosX;

        if (fz < -0.05) continue; // Backface cull cleanly

        const sx = cx + rx * R;
        const sy = cy - ry * R;
        const depth = Math.max(0, (fz + 0.05) / 1.05);

        ctx.beginPath();
        if (d.land) {
          ctx.arc(sx, sy, 1.35 + depth * 1.15, 0, Math.PI * 2);
          ctx.fillStyle = `rgba(255, 255, 255, ${(0.28 + depth * 0.7).toFixed(3)})`;
        } else {
          ctx.arc(sx, sy, 0.75, 0, Math.PI * 2);
          ctx.fillStyle = `rgba(255, 150, 95, ${(0.05 + depth * 0.08).toFixed(3)})`;
        }
        ctx.fill();
      }

      // Draw glowing pulsing orange office beacons
      const pRing = 4 + Math.sin(pulse) * 2.5;
      offices.forEach((o) => {
        const rx = o.x * cosY - o.z * sinY;
        const rz = o.x * sinY + o.z * cosY;
        const ry = o.y * cosX - rz * sinX;
        const fz = o.y * sinX + rz * cosX;
        if (fz < 0.05) return;

        const sx = cx + rx * R;
        const sy = cy - ry * R;

        ctx.beginPath();
        ctx.arc(sx, sy, pRing + 2.5, 0, Math.PI * 2);
        ctx.fillStyle = 'rgba(255, 90, 31, 0.28)';
        ctx.fill();

        ctx.beginPath();
        ctx.arc(sx, sy, 3.2, 0, Math.PI * 2);
        ctx.fillStyle = '#ff6a26';
        ctx.fill();
      });

      if (!prefersReducedMotion) {
        rotY += 0.0032;
        pulse += 0.055;
      }
    }

    draw();
  }

  /* ------------------------------------------------------------------------
     4. INTERACTIVE GRYPHOS PLAYGROUND (00:23 - 00:27)
     ------------------------------------------------------------------------ */
  const pgInput = document.getElementById('v3PlaygroundInput');
  const pgForm = document.getElementById('v3PlaygroundForm');
  const pgOut = document.getElementById('v3TelemetryOut');
  const pgBody = document.getElementById('v3TelemetryBody');
  const dockBtns = document.querySelectorAll('[data-pg-mode]');
  const presetBtns = document.querySelectorAll('[data-pg-preset]');

  function runPlayground(modeKey, customText) {
    const info = PLAYGROUND_MODES[modeKey] || PLAYGROUND_MODES.face;
    dockBtns.forEach((b) => b.classList.toggle('active', b.dataset.pgMode === modeKey));
    presetBtns.forEach((b) => b.classList.toggle('active', b.dataset.pgPreset === modeKey));

    if (pgInput && !customText) pgInput.value = info.prompt;
    if (pgOut && pgBody) {
      pgOut.classList.add('visible');
      pgBody.textContent = customText
        ? `[ENGINE] Gryphos Custom Stream • [QUERY] "${customText}" • [APIs MATCHED] 3 of 230+ • [ACCURACY] 99.2% • [DEPLOYMENT] On-Premise Ready`
        : info.output;

      if (!prefersReducedMotion && typeof gsap !== 'undefined') {
        gsap.fromTo(pgOut, { opacity: 0.4, y: 6 }, { opacity: 1, y: 0, duration: 0.3, ease: 'power2.out' });
      }
    }
  }

  dockBtns.forEach((btn) => btn.addEventListener('click', () => runPlayground(btn.dataset.pgMode)));
  presetBtns.forEach((btn) => btn.addEventListener('click', () => runPlayground(btn.dataset.pgPreset)));

  if (pgForm) {
    pgForm.addEventListener('submit', (e) => {
      e.preventDefault();
      const val = pgInput ? pgInput.value.trim() : '';
      if (!val) return;
      runPlayground('face', val);
    });
  }

  /* ------------------------------------------------------------------------
     5. PRODUCT INSPECTOR & DEMO MODALS
     ------------------------------------------------------------------------ */
  const detailModalEl = document.getElementById('v3DetailModal');
  const detailModal = detailModalEl ? new bootstrap.Modal(detailModalEl) : null;
  const demoModalEl = document.getElementById('v3DemoModal');
  const demoModal = demoModalEl ? new bootstrap.Modal(demoModalEl) : null;
  const prodSelect = document.getElementById('v3ProdSelect');
  const detTag = document.getElementById('v3DetTag');
  const detTitle = document.getElementById('v3DetTitle');
  const detDesc = document.getElementById('v3DetDesc');
  const detBullets = document.getElementById('v3DetBullets');
  const detCta = document.getElementById('v3DetCta');
  const detPageLink = document.getElementById('v3DetPageLink');
  let activeDetailDemo = 'Gryphos Platform';

  document.querySelectorAll('[data-v3-prod]').forEach((tile) => {
    tile.addEventListener('click', () => {
      const d = PRODUCT_DETAILS[tile.dataset.v3Prod];
      if (!d || !detailModal) return;
      activeDetailDemo = d.demo;
      if (detTag) detTag.textContent = d.tag;
      if (detTitle) detTitle.textContent = d.title;
      if (detDesc) detDesc.textContent = d.desc;
      if (detPageLink && d.url) detPageLink.href = d.url;
      if (detBullets) {
        detBullets.innerHTML = d.bullets
          .map(
            (b) => `
            <div class="col-md-6">
              <div class="p-2 px-3 rounded-3 small h-100" style="background: rgba(255,255,255,0.04); border: 1px solid rgba(255,255,255,0.08);">
                <i class="bi bi-check2 me-2" style="color: var(--v3-orange-bright);"></i>${b}
              </div>
            </div>`
          )
          .join('');
      }
      detailModal.show();
    });
  });

  if (detCta) {
    detCta.addEventListener('click', () => {
      if (prodSelect) prodSelect.value = activeDetailDemo;
      setTimeout(() => {
        if (demoModal) demoModal.show();
      }, 240);
    });
  }

  document.querySelectorAll('[data-demo-preset]').forEach((btn) => {
    btn.addEventListener('click', () => {
      if (prodSelect) prodSelect.value = btn.dataset.demoPreset;
    });
  });

  // Demo Form Validation
  const v3DemoForm = document.getElementById('v3DemoForm');
  const v3DemoOk = document.getElementById('v3DemoOk');
  if (v3DemoForm) {
    v3DemoForm.addEventListener('submit', (e) => {
      e.preventDefault();
      if (!v3DemoForm.checkValidity()) {
        v3DemoForm.classList.add('was-validated');
        return;
      }
      if (v3DemoOk) v3DemoOk.classList.remove('d-none');
      v3DemoForm.classList.remove('was-validated');
      v3DemoForm.reset();
    });
  }

  // Newsletter Form
  const v3NewsForm = document.getElementById('v3NewsletterForm');
  const v3NewsOk = document.getElementById('v3NewsOk');
  if (v3NewsForm) {
    v3NewsForm.addEventListener('submit', (e) => {
      e.preventDefault();
      if (v3NewsOk) v3NewsOk.classList.remove('d-none');
      v3NewsForm.reset();
    });
  }

  /* ------------------------------------------------------------------------
     6. WORD-BY-WORD LUMINANCE REVEALS & SCROLL CHOREOGRAPHY
     ------------------------------------------------------------------------ */
  function splitWordsForReveal() {
    document.querySelectorAll('[data-word-reveal]').forEach((heading) => {
      const text = heading.textContent.trim();
      const words = text.split(/\s+/);
      heading.innerHTML = words
        .map((w) => `<span class="wr-word">${w}</span>`)
        .join(' ');
    });
  }

  function initScrollAnimations() {
    if (typeof gsap === 'undefined' || typeof ScrollTrigger === 'undefined' || prefersReducedMotion) {
      return;
    }

    gsap.registerPlugin(ScrollTrigger);

    // Hero Stagger Entrance
    gsap.from('.v3-hero-stagger', {
      y: 26,
      opacity: 0,
      duration: 0.72,
      stagger: 0.1,
      ease: 'power3.out'
    });

    // Subtle floating glow pulse on central AI chip
    gsap.to('#v3AiChip', {
      y: -6,
      duration: 2.6,
      repeat: -1,
      yoyo: true,
      ease: 'sine.inOut'
    });

    // Word-by-word luminance reveals (Exact 00:03, 00:08, 00:11, 00:18, 00:28)
    document.querySelectorAll('[data-word-reveal]').forEach((heading) => {
      const mode = heading.dataset.wordReveal; // 'dark' or 'light'
      const words = heading.querySelectorAll('.wr-word');
      if (!words.length) return;

      const isHero = heading.closest('#hero') !== null;

      if (isHero) {
        gsap.fromTo(
          words,
          { color: 'rgba(255,255,255,0.2)', y: 14 },
          {
            color: '#ffffff',
            y: 0,
            duration: 0.7,
            stagger: 0.08,
            ease: 'power3.out'
          }
        );
      } else {
        gsap.fromTo(
          words,
          {
            color: mode === 'dark' ? 'rgba(255,255,255,0.2)' : '#d1d5dc',
            y: 12
          },
          {
            color: mode === 'dark' ? '#ffffff' : '#0a0a0e',
            y: 0,
            stagger: 0.08,
            ease: 'power2.out',
            scrollTrigger: {
              trigger: heading,
              start: 'top 84%',
              end: 'top 42%',
              scrub: 0.6
            }
          }
        );
      }
    });

    // Standard reveals
    gsap.utils.toArray('.v3-reveal').forEach((el) => {
      gsap.from(el, {
        y: 30,
        opacity: 0,
        duration: 0.78,
        ease: 'power3.out',
        scrollTrigger: { trigger: el, start: 'top 86%', once: true }
      });
    });

    // Staggered Bento & Product Cards
    document.querySelectorAll('.row').forEach((row) => {
      const items = row.querySelectorAll(':scope > .v3-stagger');
      if (!items.length) return;
      gsap.from(items, {
        y: 32,
        opacity: 0,
        duration: 0.7,
        stagger: 0.08,
        ease: 'power3.out',
        scrollTrigger: { trigger: row, start: 'top 85%', once: true }
      });
    });
  }

  // Boot Sequence
  window.addEventListener('load', () => {
    splitWordsForReveal();
    initDottedGlobe();
    runPreloader(() => {
      initScrollAnimations();
      if (document.fonts && document.fonts.ready && typeof ScrollTrigger !== 'undefined') {
        document.fonts.ready.then(() => ScrollTrigger.refresh());
      }
    });
  });
})();
