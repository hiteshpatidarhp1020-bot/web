/* ==========================================================================
   PRISMA AI — VERSION 2 KINETIC MOTION CHOREOGRAPHY
   Vanilla JS + GSAP 3 + ScrollTrigger + 60fps Canvas Warp Tunnel
   ========================================================================== */

(function () {
  'use strict';

  const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  /* ------------------------------------------------------------------------
     1. AUTHENTIC PRISMA AI DATA MODELS
     ------------------------------------------------------------------------ */
  const TUNNEL_PHASES = [
    {
      tag: '01 / Proprietary Computer Vision Engine',
      caption:
        'At Prisma AI, Gryphos turns any camera into a real-time cognitive sensor — analyzing faces, objects, OCR, X-rays, and human behavior simultaneously.'
    },
    {
      tag: '02 / Modular Enterprise Library',
      caption:
        'Deploy from 230+ pre-trained AI libraries and APIs — from ANPR highway monitoring and lost-bag search to AI X-ray contraband detection.'
    },
    {
      tag: '03 / Deep Convolutional Neural Networks',
      caption:
        'Cognitive self-learning creates a second language for human body language, gestures, and facial sentiment — delivering 99%+ biometric match accuracy.'
    },
    {
      tag: '04 / Data Sovereignty & Instant Triggers',
      caption:
        'Install directly on-premise or on your private cloud in weeks, dispatching automated multi-device alerts the millisecond an infraction occurs.'
    }
  ];

  const PRODUCT_MODALS = {
    gryphos: {
      tag: 'CORE PLATFORM // 230+ AI APIS',
      title: 'Gryphos Computer Vision Platform',
      demoValue: 'Gryphos Platform',
      desc: 'Prisma AI’s proprietary core platform built on Deep Convolutional Neural Networks and active machine learning. Deploys on-premise or private cloud with a dedicated Web Dashboard for every API engine.',
      items: [
        'Face, Object & Image Recognition + OCR',
        'Body Pose Estimation & Behavioral Prediction',
        '230+ Ready-to-Use Pre-Trained AI Engines',
        'Lost Baggage Search Across Video Archives',
        'Advanced AI X-Ray Prohibited Object Analysis',
        'Real-Time Multi-Device Decision Triggers'
      ]
    },
    gryfas: {
      tag: 'FINANCIAL SECURITY // BIOMETRIC AUTH',
      title: 'GryFAS — Facial Authentication & Security',
      demoValue: 'GryFAS',
      desc: 'Revolutionizes financial authentication by adding facial biometric verification to every transaction — surpassing PIN and OTP with active & passive liveness and anti-spoof protection.',
      items: [
        'Online Banking Biometric Transaction Authorization',
        'Active & Passive Liveness + Anti-Spoof Detection',
        'ATM Withdrawal Facial Match + PIN Layer',
        'Gesture Match & Intrusion Detection',
        'Enterprise Portal Secure Login Protection',
        'Seamless Integration with Core Banking Systems'
      ]
    },
    gryscan: {
      tag: 'AVIATION & TRANSIT // CUSTOMS INTELLIGENCE',
      title: 'GrySCAN — Suspicious Bag & Passenger Profiling',
      demoValue: 'GrySCAN',
      desc: 'Built for airports and customs modules, GrySCAN links Baggage Security Module (BSM) boarding-pass intelligence with dual-channel facial capture and instant mobile alerts for officers.',
      items: [
        'Suspicious Bag Detection via Gryphos Towers',
        'Green Channel & Custom Red Channel Profiling',
        'Boarding Pass & BSM Metadata Integration',
        'Repeat Offender & Loitering Detection Alerts',
        'Centralized Gryphos Passenger Database',
        'Mobile Push Notifications with Photo & Flight Info'
      ]
    },
    grysec: {
      tag: 'ENTERPRISE ACCESS // SERVER & VAULT SECURITY',
      title: 'GrySEC — Face Login & Infrastructure Control',
      demoValue: 'GrySEC',
      desc: 'Enhances critical server room login, domain access, and bank vault protection with continuous facial and gesture authentication while automating workforce attendance.',
      items: [
        'Critical Server Room Facial Login Layer',
        'Bank Vault Biometric Protection',
        'Domain Access Enhancement Beyond Passwords',
        'Automated Contactless Door Opening Control',
        'Streamlined Workforce Attendance Management',
        'Gesture Authentication & Real-Time Breach Alerts'
      ]
    },
    veri5: {
      tag: 'IDENTITY VERIFICATION // 8-LAYER DEFENSE',
      title: 'Veri5 — Contactless Identity Verification',
      demoValue: 'Veri5',
      desc: 'AI-empowered multi-factor identity verification powered by Gryphos. Combines 8 configurable verification layers to accelerate onboarding, stop impersonation, and enable password-less access.',
      items: [
        '8 Layers: Email, Mobile, Face, Govt. ID, Captcha, Gesture, Liveness & Live Video Call',
        'Contactless Hotel & Airport Check-In',
        'Face-as-a-Ticket Venue & Event Entry',
        'Official Document & Candidate Applicant Screening',
        'Password-less Verification Negating Impersonation',
        'Trusted Third-Party Data Validation & Sharing'
      ]
    }
  };

  const V2_INDUSTRIES = {
    aviation: {
      label: 'SECTOR // AVIATION',
      title: 'Aviation & Airport Operations',
      desc: 'Face-as-boarding-pass walk-through gates, unattended baggage alerts, lost-bag video search, and real-time assistance for elderly and special-needs passengers.',
      img: 'assets/img/visuals/industry-aviation.jpg',
      caps: [
        'Face-as-boarding-pass walk-through gates',
        'Alert for unattended bag or purse',
        'Lost bag retrieval from video archives',
        'Assistance to special individuals & elderly',
        'AI X-Ray prohibited object detection',
        'BSM customs & passenger profiling'
      ]
    },
    banking: {
      label: 'SECTOR // BANKING & FINANCE',
      title: 'Banking & Financial Institutions',
      desc: 'Biometric facial authentication for transactions and ATMs, bank vault protection, illegal object detection, and real-time suspicious behavior alerts.',
      img: 'assets/img/visuals/industry-security.jpg',
      caps: [
        'Face-recognition financial transactions',
        'Illegal object & weapon alerts',
        'Bank vault & server facial login',
        'Suspicious behavior real-time alerts',
        'Attendance tracking & branch security',
        'Priority assistance for elderly customers'
      ]
    },
    infrastructure: {
      label: 'SECTOR // INFRASTRUCTURE',
      title: 'Smart Highways & Traffic Automation',
      desc: 'Automated license plate recognition (ANPR) for toll collection, red-light and speed enforcement, reckless driving ticketing, and live accident alerts.',
      img: 'assets/img/visuals/industry-infrastructure.jpg',
      caps: [
        'Automated ticketing for speed & red lights',
        'Reckless driving detection via CCTV',
        'License-plate automated toll collection',
        'Real-time highway accident alerts',
        'Smart parking management system',
        'Multi-lane 24/7 ANPR monitoring'
      ]
    },
    security: {
      label: 'SECTOR // ENTERPRISE SECURITY',
      title: 'Public & Restricted Security Operations',
      desc: 'Proactive real-time monitoring for hazardous objects, crowd incidents, banned individuals, and biometric perimeter access control.',
      img: 'assets/img/visuals/industry-security.jpg',
      caps: [
        'Incident detection in dense crowds',
        'Crowd sentiment & anomaly analysis',
        'Hazardous object & weapon detection',
        'Facial authentication for entry',
        'Instant banned-person watchlist alerts',
        'Suspicious behavior monitoring'
      ]
    },
    education: {
      label: 'SECTOR // EDUCATION & EXAMS',
      title: 'Education & Examination Centers',
      desc: 'Securing high-stakes exams across 2,000+ testing facilities with candidate identity verification, suspicious eye/body movement alerts, and anti-copying intelligence.',
      img: 'assets/img/visuals/hero-optics.jpg',
      caps: [
        'Candidate identity verification',
        'Suspicious body movement detection',
        'Suspicious eye movement monitoring',
        'Banned object detection in exam halls',
        'Sentiment analysis & automated corrections',
        'Contactless attendance verification'
      ]
    },
    events: {
      label: 'SECTOR // EVENTS & VENUES',
      title: 'Large-Scale Events & Public Spaces',
      desc: 'Frictionless face-as-a-ticket entry and real-time people counting & crowd density analytics — proven at high-footfall venues and pilgrimage centers.',
      img: 'assets/img/visuals/industry-aviation.jpg',
      caps: [
        'Face-as-a-ticket contactless entry',
        'Real-time crowd density & counting',
        'Smart venue parking management',
        'Watchlist & banned person alerts',
        'Crowd sentiment & safety triggers',
        'VIP & special-assistance tracking'
      ]
    },
    manufacturing: {
      label: 'SECTOR // MANUFACTURING',
      title: 'Smart Manufacturing & Plants',
      desc: 'Ensure workplace safety and uptime with automated PPE safety gear checks, defect alerts, predictive maintenance, and supply chain tracking.',
      img: 'assets/img/visuals/industry-infrastructure.jpg',
      caps: [
        'Automated safety gear (PPE) detection',
        'Real-time product defect alerts',
        'Predictive maintenance monitoring',
        'Facial recognition for floor access',
        'Box, pallet & truck inventory tracking',
        'Automated workforce attendance'
      ]
    }
  };

  /* ------------------------------------------------------------------------
     2. 60FPS HTML5 CANVAS 3D OPTICAL HYPERSPACE TUNNEL (Matches 00:05-00:11)
     ------------------------------------------------------------------------ */
  let tunnelBoost = 0;

  function initOpticalTunnelCanvas() {
    const canvas = document.getElementById('v2TunnelCanvas');
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    let width = 0;
    let height = 0;
    let cx = 0;
    let cy = 0;

    const STAR_COUNT = 220;
    const streaks = [];

    function resize() {
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      width = canvas.clientWidth || window.innerWidth;
      height = canvas.clientHeight || window.innerHeight;
      canvas.width = Math.floor(width * dpr);
      canvas.height = Math.floor(height * dpr);
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      cx = width * 0.5;
      cy = height * 0.5;
    }

    function spawnStreak(randomZ) {
      // Distribute in an architectural tunnel ring around the vanishing center
      const angle = Math.random() * Math.PI * 2;
      const radius = 0.25 + Math.random() * 1.15;
      const isAccent = Math.random() < 0.38;
      return {
        x: Math.cos(angle) * radius * 560,
        y: Math.sin(angle) * radius * 340,
        z: randomZ ? Math.random() * 1100 + 80 : 1150,
        pz: 1150,
        size: 1.1 + Math.random() * 2.2,
        color: isAccent ? 'rgba(110, 196, 255,' : 'rgba(235, 242, 255,'
      };
    }

    resize();
    window.addEventListener('resize', resize);

    for (let i = 0; i < STAR_COUNT; i++) {
      const s = spawnStreak(true);
      s.pz = s.z;
      streaks.push(s);
    }

    let isVisible = true;
    if ('IntersectionObserver' in window) {
      const obs = new IntersectionObserver(
        (entries) => {
          isVisible = entries[0].isIntersecting;
        },
        { threshold: 0.01 }
      );
      obs.observe(canvas);
    }

    function render() {
      requestAnimationFrame(render);
      if (!isVisible) return;

      // Subtle motion trail persistence
      ctx.fillStyle = 'rgba(4, 6, 10, 0.32)';
      ctx.fillRect(0, 0, width, height);

      // Subtle vertical optical light pillar down the center (like 00:06-00:10)
      const pillarGrad = ctx.createLinearGradient(cx - 18, 0, cx + 18, 0);
      pillarGrad.addColorStop(0, 'rgba(0, 168, 232, 0)');
      pillarGrad.addColorStop(0.5, 'rgba(130, 210, 255, 0.14)');
      pillarGrad.addColorStop(1, 'rgba(0, 168, 232, 0)');
      ctx.fillStyle = pillarGrad;
      ctx.fillRect(cx - 18, 0, 36, height);

      const speed = prefersReducedMotion ? 2 : 7.5 + tunnelBoost * 34;
      tunnelBoost *= 0.9;

      for (let i = 0; i < streaks.length; i++) {
        const s = streaks[i];
        s.pz = s.z;
        s.z -= speed;

        if (s.z < 18) {
          const fresh = spawnStreak(false);
          streaks[i] = fresh;
          continue;
        }

        const fov = 420;
        const sx = cx + (s.x / s.z) * fov;
        const sy = cy + (s.y / s.z) * fov;
        const px = cx + (s.x / s.pz) * fov;
        const py = cy + (s.y / s.pz) * fov;

        if (sx < -60 || sx > width + 60 || sy < -60 || sy > height + 60) {
          streaks[i] = spawnStreak(false);
          continue;
        }

        const depthRatio = 1 - s.z / 1150;
        const alpha = Math.min(0.92, depthRatio * 1.15);
        const lw = s.size * (0.45 + depthRatio * 2.1);

        ctx.beginPath();
        ctx.moveTo(px, py);
        ctx.lineTo(sx, sy);
        ctx.strokeStyle = `${s.color}${alpha.toFixed(3)})`;
        ctx.lineWidth = lw;
        ctx.lineCap = 'round';
        ctx.stroke();

        // Crisp bokeh node head on close particles
        if (depthRatio > 0.62) {
          ctx.beginPath();
          ctx.arc(sx, sy, lw * 1.15, 0, Math.PI * 2);
          ctx.fillStyle = `${s.color}${(alpha * 0.45).toFixed(3)})`;
          ctx.fill();
        }
      }
    }

    // Fill initial dark background cleanly
    ctx.fillStyle = '#04060a';
    ctx.fillRect(0, 0, width, height);
    render();
  }

  /* ------------------------------------------------------------------------
     3. NAVBAR SCROLL STATE, DARK ZONE DETECTION & PROGRESS BAR
     ------------------------------------------------------------------------ */
  const v2Navbar = document.getElementById('v2Navbar');
  const v2Progress = document.getElementById('v2ScrollProgress');
  const darkZones = document.querySelectorAll('[data-dark-zone="true"]');
  const navPillLinks = document.querySelectorAll('.v2-pill-link[data-nav-sec]');

  function updateChrome() {
    const sy = window.scrollY || document.documentElement.scrollTop;
    const maxScroll = document.documentElement.scrollHeight - window.innerHeight;
    const pct = maxScroll > 0 ? (sy / maxScroll) * 100 : 0;

    if (v2Progress) v2Progress.style.width = pct.toFixed(2) + '%';
    if (v2Navbar) v2Navbar.classList.toggle('is-scrolled', sy > 36);

    // Check if navbar overlaps a dark section
    let inDark = false;
    const probeY = 44;
    darkZones.forEach((zone) => {
      const rect = zone.getBoundingClientRect();
      if (rect.top <= probeY && rect.bottom >= probeY) {
        inDark = true;
      }
    });

    if (v2Navbar) v2Navbar.classList.toggle('is-dark-zone', inDark);
    if (v2Progress) v2Progress.classList.toggle('on-dark', inDark);

    // Active nav pill tracking
    const secs = ['hero', 'platform', 'products', 'industries', 'company'];
    let current = 'hero';
    secs.forEach((id) => {
      const el = document.getElementById(id);
      if (el) {
        const r = el.getBoundingClientRect();
        if (r.top <= window.innerHeight * 0.42) current = id;
      }
    });

    navPillLinks.forEach((link) => {
      const isAct = link.dataset.navSec === current;
      link.classList.toggle('active', isAct);
      let dot = link.querySelector('.v2-pill-dot');
      if (isAct && !dot) {
        dot = document.createElement('span');
        dot.className = 'v2-pill-dot';
        dot.setAttribute('aria-hidden', 'true');
        link.prepend(dot);
      } else if (!isAct && dot) {
        dot.remove();
      }
    });
  }

  window.addEventListener('scroll', updateChrome, { passive: true });
  updateChrome();

  /* ------------------------------------------------------------------------
     4. INTERACTIVE PRODUCT MODAL (FROM 3D FAN CARDS)
     ------------------------------------------------------------------------ */
  const productModalEl = document.getElementById('v2ProductModal');
  const productModal = productModalEl ? new bootstrap.Modal(productModalEl) : null;
  const modalTag = document.getElementById('v2ModalTag');
  const modalTitle = document.getElementById('v2ModalTitle');
  const modalDesc = document.getElementById('v2ModalDesc');
  const modalList = document.getElementById('v2ModalList');
  const modalDemoBtn = document.getElementById('v2ModalDemoBtn');
  const v2ProductSelect = document.getElementById('v2Product');
  let activeModalDemoValue = 'Gryphos Platform';

  function openProductDetail(key) {
    const info = PRODUCT_MODALS[key];
    if (!info || !productModal) return;
    activeModalDemoValue = info.demoValue;
    if (modalTag) modalTag.textContent = info.tag;
    if (modalTitle) modalTitle.textContent = info.title;
    if (modalDesc) modalDesc.textContent = info.desc;
    if (modalList) {
      modalList.innerHTML = info.items
        .map(
          (item) => `
          <div class="col-md-6">
            <div class="border rounded-3 px-3 py-2 small text-dark bg-light h-100 d-flex align-items-start gap-2">
              <i class="bi bi-check2 text-dark mt-1"></i>
              <span>${item}</span>
            </div>
          </div>`
        )
        .join('');
    }
    productModal.show();
  }

  document.querySelectorAll('[data-product-modal]').forEach((card) => {
    card.addEventListener('click', () => openProductDetail(card.dataset.productModal));
    card.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' || e.key === ' ') {
        e.preventDefault();
        openProductDetail(card.dataset.productModal);
      }
    });
  });

  if (modalDemoBtn) {
    modalDemoBtn.addEventListener('click', () => {
      if (v2ProductSelect) v2ProductSelect.value = activeModalDemoValue;
      setTimeout(() => {
        const demoSec = document.getElementById('demo');
        if (demoSec) demoSec.scrollIntoView({ behavior: 'smooth' });
      }, 220);
    });
  }

  /* ------------------------------------------------------------------------
     5. INTERACTIVE 7-INDUSTRY SWITCHER
     ------------------------------------------------------------------------ */
  const indTabs = document.querySelectorAll('[data-v2-ind]');
  const indImg = document.getElementById('v2IndImg');
  const indLabel = document.getElementById('v2IndLabel');
  const indTitle = document.getElementById('v2IndTitle');
  const indDesc = document.getElementById('v2IndDesc');
  const indCaps = document.getElementById('v2IndCaps');

  function renderV2Industry(key) {
    const data = V2_INDUSTRIES[key];
    if (!data) return;
    indTabs.forEach((t) => t.classList.toggle('active', t.dataset.v2Ind === key));
    if (indImg) {
      indImg.src = data.img;
      indImg.alt = data.title;
    }
    if (indLabel) indLabel.textContent = data.label;
    if (indTitle) indTitle.textContent = data.title;
    if (indDesc) indDesc.textContent = data.desc;
    if (indCaps) {
      indCaps.innerHTML = data.caps
        .map(
          (c) => `
          <div class="col-sm-6">
            <div class="small text-dark border rounded-3 px-3 py-2 bg-light h-100">
              <i class="bi bi-check2 me-2"></i>${c}
            </div>
          </div>`
        )
        .join('');
    }
  }

  indTabs.forEach((tab) => {
    tab.addEventListener('click', () => renderV2Industry(tab.dataset.v2Ind));
  });
  renderV2Industry('aviation');

  /* ------------------------------------------------------------------------
     6. DEMO FORM VALIDATION
     ------------------------------------------------------------------------ */
  const v2Form = document.getElementById('v2DemoForm');
  const v2Success = document.getElementById('v2DemoSuccess');
  const v2ConfirmedProd = document.getElementById('v2ConfirmedProd');

  if (v2Form) {
    v2Form.addEventListener('submit', (e) => {
      e.preventDefault();
      if (!v2Form.checkValidity()) {
        v2Form.classList.add('was-validated');
        return;
      }
      if (v2ConfirmedProd && v2ProductSelect) {
        v2ConfirmedProd.textContent = v2ProductSelect.value || 'Gryphos Platform';
      }
      if (v2Success) v2Success.classList.remove('d-none');
      v2Form.classList.remove('was-validated');
      v2Form.reset();
    });
  }

  /* ------------------------------------------------------------------------
     7. GSAP + SCROLLTRIGGER — ALL 5 SIGNATURE VIDEO ANIMATIONS
     ------------------------------------------------------------------------ */
  function initKineticAnimations() {
    if (typeof gsap === 'undefined' || typeof ScrollTrigger === 'undefined') {
      document.querySelectorAll('.v2-counter').forEach((el) => {
        el.textContent = Number(el.dataset.target).toLocaleString();
      });
      document.querySelectorAll('.v2-metric-row').forEach((row) => {
        const fill = row.querySelector('.v2-pill-slider-fill');
        if (fill) fill.style.width = (row.dataset.sliderTarget || 80) + '%';
      });
      return;
    }

    gsap.registerPlugin(ScrollTrigger);

    if (prefersReducedMotion) {
      document.querySelectorAll('.v2-counter').forEach((el) => {
        el.textContent = Number(el.dataset.target).toLocaleString();
      });
      document.querySelectorAll('.v2-metric-row').forEach((row) => {
        const fill = row.querySelector('.v2-pill-slider-fill');
        if (fill) fill.style.width = (row.dataset.sliderTarget || 80) + '%';
      });
      return;
    }

    /* === ANIMATION #1: HERO ENTRY + PINNED INWARD-REACHING ARMS === */
    const reachLeft = document.getElementById('v2ReachLeft');
    const reachRight = document.getElementById('v2ReachRight');
    const heroTitle = document.getElementById('v2HeroTitle');
    const heroSub = document.getElementById('v2HeroSubtitle');
    const heroOrb = document.getElementById('v2HeroOrb');

    // Clean opening entrance (Matches 00:00 -> 00:01)
    const entryTl = gsap.timeline({ defaults: { ease: 'power3.out' } });
    entryTl
      .from(heroTitle, { y: 24, opacity: 0, duration: 0.75 })
      .from(heroSub, { y: 26, opacity: 0, duration: 0.75 }, '-=0.45')
      .fromTo(
        reachLeft,
        { xPercent: -72, opacity: 0 },
        { xPercent: -14, opacity: 1, duration: 1.05, ease: 'power3.out' },
        '-=0.55'
      )
      .fromTo(
        reachRight,
        { xPercent: 72, opacity: 0 },
        { xPercent: 14, opacity: 1, duration: 1.05, ease: 'power3.out' },
        '<'
      );

    /* === ANIMATION #3: EXPANDING PILL SLIDERS + COUNTERS (All Breakpoints) === */
    document.querySelectorAll('.v2-metric-row').forEach((row) => {
      const targetPct = Number(row.dataset.sliderTarget || 82);
      const fill = row.querySelector('.v2-pill-slider-fill');
      const counter = row.querySelector('.v2-counter');

      if (fill) {
        gsap.fromTo(
          fill,
          { width: '11%' },
          {
            width: targetPct + '%',
            ease: 'power2.out',
            scrollTrigger: {
              trigger: row,
              start: 'top 86%',
              end: 'top 36%',
              scrub: 0.65
            }
          }
        );
      }

      if (counter) {
        const endVal = Number(counter.dataset.target || 0);
        const obj = { v: 0 };
        ScrollTrigger.create({
          trigger: row,
          start: 'top 85%',
          once: true,
          onEnter: () => {
            gsap.to(obj, {
              v: endVal,
              duration: 1.35,
              ease: 'power2.out',
              onUpdate: () => {
                counter.textContent = Math.round(obj.v).toLocaleString();
              }
            });
          }
        });
      }
    });

    /* === STANDARD EDITORIAL REVEALS === */
    gsap.utils.toArray('.v2-reveal').forEach((el) => {
      gsap.from(el, {
        y: 28,
        opacity: 0,
        duration: 0.78,
        ease: 'power3.out',
        scrollTrigger: { trigger: el, start: 'top 86%', once: true }
      });
    });

    document.querySelectorAll('.row').forEach((row) => {
      const staggers = row.querySelectorAll(':scope > .v2-stagger');
      if (!staggers.length) return;
      gsap.from(staggers, {
        y: 26,
        opacity: 0,
        duration: 0.7,
        stagger: 0.09,
        ease: 'power3.out',
        scrollTrigger: { trigger: row, start: 'top 85%', once: true }
      });
    });

    /* === DESKTOP PINNED CHOREOGRAPHY (>= 992px) === */
    const mm = gsap.matchMedia();

    mm.add('(min-width: 992px)', () => {
      // 1) HERO PINNED REACHING & RETRACTION (00:01 -> 00:05)
      if (reachLeft && reachRight) {
        const heroScrollTl = gsap.timeline({
          scrollTrigger: {
            trigger: '#hero',
            start: 'top top',
            end: '+=920',
            pin: true,
            scrub: 0.75,
            anticipatePin: 1
          }
        });

        heroScrollTl
          // Reach dramatically inward toward each other across the headline
          .to(reachLeft, { xPercent: 10, duration: 0.52, ease: 'power2.inOut' }, 0)
          .to(reachRight, { xPercent: -10, duration: 0.52, ease: 'power2.inOut' }, 0)
          .to(heroOrb, { scale: 1.18, opacity: 0.9, duration: 0.52 }, 0)
          // Smoothly retract back toward edges before dark tunnel arrives
          .to(reachLeft, { xPercent: -36, opacity: 0.35, duration: 0.48, ease: 'power2.in' }, 0.52)
          .to(reachRight, { xPercent: 36, opacity: 0.35, duration: 0.48, ease: 'power2.in' }, 0.52)
          .to('#v2HeroType', { scale: 0.95, opacity: 0.75, duration: 0.48 }, 0.52);
      }

      // 2) DARK OPTICAL HYPERSPACE TUNNEL PINNED MORPH (00:05 -> 00:11)
      const tunnelWords = gsap.utils.toArray('.v2-tunnel-word');
      const tunnelDots = document.querySelectorAll('[data-tunnel-dot]');
      const tunnelTag = document.getElementById('v2TunnelTag');
      const tunnelCaption = document.getElementById('v2TunnelCaption');
      let lastTunnelIdx = 0;

      function setTunnelPhase(idx) {
        if (idx === lastTunnelIdx) return;
        lastTunnelIdx = idx;
        tunnelDots.forEach((d, i) => d.classList.toggle('active', i === idx));
        const phase = TUNNEL_PHASES[idx];
        if (phase && tunnelTag && tunnelCaption) {
          tunnelTag.textContent = phase.tag;
          tunnelCaption.textContent = phase.caption;
          gsap.fromTo(
            tunnelCaption,
            { opacity: 0.35, y: 8 },
            { opacity: 1, y: 0, duration: 0.35, ease: 'power2.out' }
          );
        }
      }

      if (tunnelWords.length === 4) {
        gsap.set(tunnelWords, { opacity: 0, scale: 0.82 });
        gsap.set(tunnelWords[0], { opacity: 1, scale: 1 });

        const tunnelTl = gsap.timeline({
          scrollTrigger: {
            trigger: '#platform',
            start: 'top top',
            end: '+=2200',
            pin: true,
            scrub: 0.75,
            anticipatePin: 1,
            onUpdate: (self) => {
              const vel = Math.abs(self.getVelocity());
              tunnelBoost = Math.min(1.6, Math.max(tunnelBoost, vel / 2400));
              const idx = Math.min(3, Math.floor(self.progress * 4));
              setTunnelPhase(idx);
            }
          }
        });

        // Phase 0 -> 1 -> 2 -> 3 smooth 3D zoom crossfade
        tunnelTl
          .to(tunnelWords[0], { scale: 1.18, opacity: 0, duration: 0.8 }, 0.4)
          .fromTo(tunnelWords[1], { scale: 0.82, opacity: 0 }, { scale: 1, opacity: 1, duration: 0.8 }, 0.9)
          .to(tunnelWords[1], { scale: 1.18, opacity: 0, duration: 0.8 }, 1.9)
          .fromTo(tunnelWords[2], { scale: 0.82, opacity: 0 }, { scale: 1, opacity: 1, duration: 0.8 }, 2.4)
          .to(tunnelWords[2], { scale: 1.18, opacity: 0, duration: 0.8 }, 3.4)
          .fromTo(tunnelWords[3], { scale: 0.82, opacity: 0 }, { scale: 1, opacity: 1, duration: 0.8 }, 3.9)
          .to(tunnelWords[3], { scale: 1.06, duration: 0.6 }, 4.8);
      }

      // 4) 3D ISOMETRIC STACK -> UNFOLDING CURVED HORIZONTAL CARD FAN (00:15 -> 00:17)
      const fanCards = gsap.utils.toArray('.v2-fan-card');
      if (fanCards.length === 5) {
        // Compute responsive spread so 5 cards fit gracefully across 992px..1600px+
        const spread = Math.min(242, Math.max(178, (window.innerWidth - 260) / 4.4));
        const xTargets = [-spread * 2, -spread, 0, spread, spread * 2];
        const yArch = [20, 6, 0, 6, 20];
        const rotYTargets = [15, 7, 0, -7, -15];
        const stackOffsets = [-76, -38, 0, 38, 76];

        // Start as a tight isometric 3D floating stack (Matches 00:15)
        fanCards.forEach((card, i) => {
          gsap.set(card, {
            x: 0,
            y: stackOffsets[i],
            z: (4 - i) * 16,
            rotateX: 62,
            rotateY: 0,
            rotateZ: -32,
            scale: 0.84,
            zIndex: 5 - i
          });
        });

        const fanTl = gsap.timeline({
          scrollTrigger: {
            trigger: '#products',
            start: 'top top',
            end: '+=1650',
            pin: true,
            scrub: 0.85,
            anticipatePin: 1
          }
        });

        // Stage A: Lift upright slightly & begin separation (00:15 -> 00:16)
        fanCards.forEach((card, i) => {
          fanTl.to(
            card,
            {
              rotateX: 14,
              rotateZ: -8,
              x: xTargets[i] * 0.45,
              y: stackOffsets[i] * 0.3,
              scale: 0.94,
              duration: 0.45,
              ease: 'power2.out'
            },
            0
          );
        });

        // Stage B: Fully unfold into the crisp 5-card curved editorial fan (00:16 -> 00:17)
        fanCards.forEach((card, i) => {
          fanTl.to(
            card,
            {
              rotateX: 0,
              rotateZ: 0,
              rotateY: rotYTargets[i],
              x: xTargets[i],
              y: yArch[i],
              z: 0,
              scale: 1,
              duration: 0.65,
              ease: 'power3.out'
            },
            0.42
          );
        });
      }

      // 5) GIANT HORIZONTAL KINETIC TYPOGRAPHY SWEEP (00:18 -> 00:22)
      const giantLine = document.getElementById('v2GiantLine');
      if (giantLine) {
        gsap.to(giantLine, {
          x: () => -Math.max(300, giantLine.scrollWidth - window.innerWidth + 120),
          ease: 'none',
          scrollTrigger: {
            trigger: '#vision',
            start: 'top top',
            end: '+=1350',
            pin: true,
            scrub: 0.75,
            anticipatePin: 1,
            invalidateOnRefresh: true
          }
        });
      }
    });

    // Mobile & Tablet graceful giant text horizontal parallax without pinning
    mm.add('(max-width: 991.98px)', () => {
      const giantLine = document.getElementById('v2GiantLine');
      if (giantLine) {
        gsap.to(giantLine, {
          x: () => -Math.max(180, giantLine.scrollWidth - window.innerWidth + 60),
          ease: 'none',
          scrollTrigger: {
            trigger: '#vision',
            start: 'top bottom',
            end: 'bottom top',
            scrub: 0.6,
            invalidateOnRefresh: true
          }
        });
      }
    });
  }

  window.addEventListener('load', () => {
    initOpticalTunnelCanvas();
    initKineticAnimations();
    if (document.fonts && document.fonts.ready && typeof ScrollTrigger !== 'undefined') {
      document.fonts.ready.then(() => ScrollTrigger.refresh());
    }
  });
})();
