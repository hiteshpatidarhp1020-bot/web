/* ==========================================================================
   PRISMA AI — ABOUT PAGE (INDEX3 DESIGN SYSTEM & ANIMATIONS)
   100% Authentic Content from https://www.prisma.ai/about
   Vanilla JS + GSAP 3 + ScrollTrigger
   ========================================================================== */

(function () {
  'use strict';

  const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  /* ------------------------------------------------------------------------
     1. ORIGINAL EXECUTIVE TEAM DATA (ALL 13 MEMBERS FROM prisma.ai/about)
     ------------------------------------------------------------------------ */
  const EXECUTIVE_TEAM = [
    {
      name: 'Dr. Shreeram Iyer',
      role: 'Chairman & Group CEO',
      img: 'assets/img/team/shreeram-iyer.png',
      bio: [
        'Dr. Shreeram Iyer has 25 years of experience in the software industry. Amongst his many notable previous experiences was the role of Senior VP of International Operations at Patni Computers.',
        'He has a PhD by the European International University (EIU), Paris in the field of Computer Vision and Business Specification. He has Bachelors in Mechanical Engineering. He has also pursued EP, Artificial Intelligence and Business specifications from Massachusetts Institute of Technology (MIT).'
      ]
    },
    {
      name: 'Amitabh Roy Chowdhury',
      role: 'Group COO',
      img: 'assets/img/team/amitabh-roy-chowdhury.png',
      bio: [
        'Amitabh Roy Chowdhury has over 25 years of experience in IT, in multiple Senior Management roles in Operations, Account Management, Marketing and Business Development of Software Products and IT Solutions.',
        'He has extensive International exposure across the continents of US, Western Europe and South Asia through premier IT Organizations like Tata Consultancy Services, i-flex Solutions, Oracle Financial Software Services, QS Advisory etc.'
      ]
    },
    {
      name: 'Asha Suvarna',
      role: 'Chief Financial Officer',
      img: 'assets/img/team/asha-suvarna.jpg',
      bio: [
        'Asha Suvarna is a Chartered Accountant with over 23 years of experience in global MNCs. She has held senior leadership roles including Group CFO – South Asia at Dentsu Media India, Finance Director – Compliance & M&A at GroupM Media India, and Senior Commercial Director at Mindshare Fulcrum, GroupM Media India.',
        'She brings strong expertise in financial strategy, compliance, mergers & acquisitions, and business transformation, and is known for driving operational excellence, strategic growth, and sustainable value creation across complex organizations.',
        'She had played significant role as part of the industry committee for media sector during two major financial developments in India; the implementation of Goods and Services Tax (GST) and the introduction of Equalisation levy.'
      ]
    },
    {
      name: 'Hari Janardhanan',
      role: 'Chief Investment Officer',
      img: 'assets/img/team/hari-janardhanan.jpg',
      bio: [
        'Over 30 years of extensive client-facing experience in Investment Banking and Corporate Finance Advisory, with expertise in handling complex valuations, Financial Due Diligence, M&A, IPO readiness, and transaction execution.',
        'Hari has worked with leading organizations such as EY, Deloitte, HDFC, and reputable investment banks and sovereign wealth funds in the MENA/GCC region and is a professional from the Institute of Chartered Accountants of India, Institute of Cost & Works Accountants of India, a certified Big Data expert from IIM Kashipur and a Charterholder of the Chartered Institute for Securities & Investment (UK).',
        'Hari is recognized for a strong track record as a seasoned finance and investment leader with experience spanning across the Middle East, Asia Pacific, and Europe.'
      ]
    },
    {
      name: 'Vinit Jha',
      role: 'Chief Product & Technology Officer',
      img: 'assets/img/team/vinit-jha.jpg',
      bio: [
        "Vinit Jha brings more than 27 years of global leadership experience across product, artificial intelligence, enterprise technology, and large-scale operations spanning Financial Services, Healthcare & Life Sciences, Managed Services, and Digital platforms. He has led technology portfolios exceeding $200 million, managed teams of more than 1,200 professionals across six countries, and holds two patents in distributed systems resilience and real-time digital messaging. His innovation track record includes pioneering one of Australia's earliest digital home-loan e-lodgement platforms.",
        'Prior to joining Prisma AI, Vinit held senior executive leadership roles at ANZ Bank and NTT DATA, where he led enterprise-scale transformation, cloud modernisation, technology strategy, and AI-enabled operational resilience. His achievements include delivering more than $150 million in productivity gains and cost optimisation, scaling platform capacity tenfold during COVID-19, and enabling 50,000 employees across 28 countries to work remotely with zero regulatory incidents.',
        'A Graduate of the Australian Institute of Company Directors (GAICD), Executive MBA holder from IE Business School, and certified Scaled Agile Program Consultant (SPC), Vinit combines strong governance and board-level capability with deep expertise in product, AI, engineering, and organisational transformation.',
        "As Chief Product, AI & Technology Officer at Prisma AI, Vinit will lead the company's global product vision, AI strategy, and technology platform, accelerating innovation in computer vision and operational intelligence while scaling the business for its next phase of growth."
      ]
    },
    {
      name: 'Krishnan Ramamurthy',
      role: 'CBO & Director Channels',
      img: 'assets/img/team/krishnan-ramamurthy.png',
      bio: [
        'Business growth leader with 35+ years of experience across Enterprise, Government, PSU, and Institutional sectors.',
        'Expertise in business scaling, market penetration, customer acquisition, and revenue growth.',
        'Served as CEO & President at DEXIT Global Ltd, leading 480+ employees across 237 centres and driving significant business growth.',
        'Strong experience in strategic client relationships, government contracts, channel partnerships, and international market expansion across the US, UK, Europe, and Southeast Asia.'
      ]
    },
    {
      name: 'Wg Cdr Naresh Taneja (Retd.)',
      role: 'Executive Vice President HR & Admin',
      img: 'assets/img/about/team/naresh-taneja.jpg',
      bio: [
        "With over 46 years of experience in human resources and administration, Wg Cdr Naresh Taneja (Retd.) combines strategic leadership with practical expertise, fostering organizational excellence across diverse sectors. His career began with 21 years of service in the Indian Air Force, where he received specialized training at the Defence Institute of Psychological Research for officers' selection. This foundation in performance, discipline, and human psychology laid the groundwork for his transition into the private sector.",
        'In his most recent role as Group President (HR and Administration) at a leading infrastructure company, Wg Cdr Taneja played a pivotal role in shaping the HR landscape for over 6,500 employees. He has been instrumental in driving digital transformation, cultivating agile leadership, and developing policies that enhance both organizational performance and employee engagement. His expertise spans labor negotiations, mergers and acquisitions, and talent acquisition, having personally interviewed and selected leaders at all levels—from executives to CXOs—across industries such as automobile, manufacturing, IT, and infrastructure.',
        'A recognized thought leader in the HR space, Wg Cdr Naresh Taneja (Retd.) has received prestigious accolades including "CHRO of the Year" and is consistently named among Asia’s "50 Most Talented Global HR Leaders." His deep understanding of human behavior and psychology has made him a sought-after speaker and advisor.',
        'He holds advanced degrees in Defence Studies, Psychology, and Biology, alongside certifications such as Certified Master Coach, Certified Global Professional in Human Resources, and Certified Independent Director. Fluent in Hindi, English, Nepali, Urdu, and Chinese, he is well-versed in managing board and CXO-level challenges in progressive, digitally-driven organizations.'
      ]
    },
    {
      name: 'Chandrakant Joge',
      role: 'Compliance Head',
      img: 'assets/img/about/team/chandrakant-joge.png',
      bio: [
        'Chandrakant Joge is an experienced legal and corporate secretarial professional with expertise in IPO readiness, corporate compliance, governance, and legal advisory. He has played a pivotal role in both pre- and post-IPO activities, including DRHP preparation, regulatory coordination, and stakeholder management.',
        'He is proficient in ensuring statutory compliance under the Companies Act, SEBI Regulations, FEMA, and other applicable laws, while maintaining corporate records and managing statutory filings. He is adept at upholding high standards of corporate governance, advising the Board of Directors, and organizing Board, Committee, and General Meetings.',
        'His legal expertise includes contract drafting, intellectual property (IP) filings, and liaising with external legal advisors. He also has experience in establishing legal entities, including copyright societies.'
      ]
    },
    {
      name: 'Prakash Salunkhe',
      role: 'CISO (India Operations)',
      img: 'assets/img/about/team/prakash-salunkhe.png',
      bio: [
        'Prakash Salunkhe has over 13 years of experience in Information and Cybersecurity and currently serves as the Chief Information Security Officer (CISO) for India Operations. He leads security strategy, governance, and risk management initiatives, securing critical environments across banks, public sector undertakings (PSUs), and IT organizations.',
        'He has successfully delivered tailored cybersecurity solutions in high-impact environments. A Certified Lead Implementer and Auditor for ISO standards, Prakash is a strong advocate of continuous learning and fostering a security-aware culture across organizations.'
      ]
    },
    {
      name: 'Dr. Pratik Bajaria',
      role: 'Product Head',
      img: 'assets/img/about/team/pratik-bajaria.png',
      bio: [
        'Dr. Pratik Bajaria holds a Ph.D. and has over 9 years of experience in Artificial Intelligence (AI) and Analytics, with expertise in Computer Vision and Deep Reinforcement Learning (DRL). He has worked across the Power Systems, Renewable Energy, and AI Infrastructure domains, supported by a strong foundation in Control Theory and Machine Learning.',
        'His research experience includes Aperiodic Sampled-Data Systems and Random Forest Q-Learning. Throughout his career, he has been associated with organizations such as TCS, Mahindra Susten, and SCOPE T&M.'
      ]
    },
    {
      name: 'Rajat Bose',
      role: 'Operations Head Projects',
      img: 'assets/img/about/team/rajat-bose.png',
      bio: [
        'Rajat Bose has over 20 years of experience in AI operations and enterprise delivery, having held leadership roles at Ernst & Young, Razorthink, Indus Net, and Teradata. He has successfully delivered large-scale AI, Machine Learning (ML), and data platform initiatives, with a strong focus on AI governance and regulatory compliance.',
        'His expertise spans forensic analysis and data engineering, with extensive experience across the banking, insurance, and public sectors. He is known for disciplined execution, strategic thinking, and effective cross-functional leadership.'
      ]
    },
    {
      name: 'Mayur Thorve',
      role: 'Technology Head',
      img: 'assets/img/about/team/mayur-thorve.jpg',
      bio: [
        'Technology Head with 11+ years of experience in application development, software engineering, and technology solutions, including experience in the Credit Card and ATM division at HDFC Bank.',
        'Expertise in AI products and solutions, full stack development, scalable application design, and secure software development, focused on business driven technology solutions.',
        'Drives technology innovation and has received multiple awards at Prisma AI, including Best Employee, Best Technology Adapter, and Mr. Reliable.',
        'Certified in AI Product Management, Agile, Scrum, and Kanban, with a focus on building intelligent and future ready digital solutions.'
      ]
    },
    {
      name: 'Vishal Sakpal',
      role: 'IT Head',
      img: 'assets/img/about/team/vishal-sakpal.jpg',
      bio: [
        'Senior IT Manager with 8+ years of experience in IT operations, infrastructure, cybersecurity, and cloud services.',
        'Expertise in IT strategy, network management, cybersecurity, cloud technologies, IT governance, and disaster recovery.',
        'Experienced in leading IT operations, managing infrastructure, security architecture, cloud services, vendors, budgets, and regulatory compliance.',
        'Strong experience in cybersecurity assessments, SOC, EDR, VAPT, vulnerability management, and security audits, including successful completion of a SEBI Cyber Security Audit.'
      ]
    }
  ];

  /* ------------------------------------------------------------------------
     2. ORIGINAL ADVISORS DATA (ALL 5 ADVISORS FROM prisma.ai/about)
     ------------------------------------------------------------------------ */
  const ADVISORS = [
    {
      name: 'Juspreet Singh Walia',
      role: 'Marketing',
      img: 'assets/img/about/advisors/juspreet-singh-walia.jpg',
      bio: [
        'Juspreet has 20-plus years of global experience in brand strategy, strategic partnerships, and business growth across technology, media, and enterprise ecosystems. He is recognised for his ability to build high-impact brand narratives and position advanced technology platforms for global adoption.',
        'He has previously served as Director at Sony. His early career includes working at Carlin Equities in New York and SAP America, a Fortune Global 500 Company.',
        'He holds a Bachelor of Science in Finance and MIS from Drexel University, USA, and is certified in Blockchain and Crypto Applications from MIT Sloan Executive Education.'
      ]
    },
    {
      name: 'Santosh Chavan',
      role: 'Govt Liaisoning',
      img: 'assets/img/about/advisors/santosh-chavan.png',
      bio: [
        'Santosh Chavan is a successful entrepreneur and is the Chairman of Seawoods Group of Companies. Santosh has been handling India Sales and Marketing for Prisma since June, 2020.'
      ]
    },
    {
      name: 'Binal Soni',
      role: 'Graphology',
      img: 'assets/img/about/advisors/binal-soni.png',
      bio: [
        'Binal Soni is a Counseling Psychologist with over nine years of experience working closely with students and professionals. After spending a decade in software programming, she transitioned into career counseling, driven by her passion for nurturing young minds and helping individuals achieve their full potential.',
        "She holds a Master's degree in Computer Applications as well as a Master's degree in Counseling Psychology. She has also completed Global Career Counseling from the University of California, is a Certified Career Analyst from eduMilestones, and an ISO Certified Handwriting Analyst.",
        'Her expertise extends to Dream Analysis, Transactional Analysis, and Parenting Coaching. More than 1,800 students have benefited from her counseling services, receiving guidance to make informed career decisions and build fulfilling, successful careers.'
      ]
    },
    {
      name: 'Jay Vora',
      role: 'Legal',
      img: 'assets/img/about/advisors/jay-vora.png',
      bio: [
        'Jay Vora is a Legal Advisor, Advocate, and Chartered Accountant. He has expertise in litigation related to civil and property matters, income tax and indirect tax, intellectual property rights, testamentary matters, and labour laws.',
        'On the non-litigation side, he has extensive experience in drafting and reviewing agreements, including joint venture agreements, tender agreements, and domestic and international contracts. He also advises on cross border corporate structuring and restructuring from a taxation perspective, as well as mergers and acquisitions and debt transactions.'
      ]
    },
    {
      name: 'Maj Gen (Dr.) Pawan Anand (Retd.)',
      role: 'Advisor on Cyber Security & Defence Industry',
      img: 'assets/img/about/advisors/pawan-anand.png',
      bio: [
        "Maj Gen (Dr.) Pawan Anand (Retd.), PhD, was awarded the President's Gold Medal at the National Defence Academy (First in Merit) and the Sword of Honour at the Indian Military Academy. With 36 years in the Army, having seen action in the Kargil War and later in counterinsurgency operations.",
        'He was awarded twice by the President of India and twice by the Chief of the Army. A mechanical engineer, he has a Masters in Strategic & Security Studies and a Doctorate in Management. He was Secretary General of the Highway Operators Association in India for a period. He is currently a Director at Centre for Emerging Technologies, USI of India. He also serves as a Mentor at the prestigious National Defence College.',
        'He is a PhD guide and a Director/Strategic Board Advisor to global corporate entities on topics such as geopolitical risk, defence industry, and AI applications. He has established a Cyber Center of Excellence for the USI in New Delhi, in alignment with NSC and DCA.',
        'He has been a regular spokesperson at the UN Internet Governance Forum, the REAIM Summit, and the India AI Impact Summit (Ministry of Defence Panel). He has played an integral role in policy drafting for the Indian military, contributed to AI training for military officers, and worked on formulating Confidence-Building Measures for REAIM.'
      ]
    }
  ];

  /* ------------------------------------------------------------------------
     3. ALL 10 ALLIANCE PARTNERS (FROM prisma.ai/about)
     ------------------------------------------------------------------------ */
  const PARTNERS = [
    { name: 'Sentientlogics AI Consultancies Co. LLC', img: 'assets/img/about/partners/sentientlogics.png' },
    { name: 'SYLOZ International LLC', img: 'assets/img/about/partners/syloz.png' },
    { name: 'LA Esfera Technovate', img: 'assets/img/about/partners/la-esfera.png' },
    { name: 'Red Ballon', img: 'assets/img/about/partners/red-ballon.png' },
    { name: 'Software Products Italia', img: 'assets/img/about/partners/software-products-italia.png' },
    { name: 'ETI Group Co', img: 'assets/img/about/partners/eti-group.png' },
    { name: 'Spectra Narnolia', img: 'assets/img/about/partners/spectra-narnolia.png' },
    { name: 'Nityo Infotech Corporation', img: 'assets/img/about/partners/nityo.png' },
    { name: 'Pitney Bowes Software Pte. Ltd.', img: 'assets/img/about/partners/pitney-bowes.png' },
    { name: 'BAT Ventures Pte. Ltd.', img: 'assets/img/about/partners/bat-ventures.png' }
  ];

  /* ------------------------------------------------------------------------
     4. ALL 32 USERS / CUSTOMERS (FROM prisma.ai/about)
     ------------------------------------------------------------------------ */
  const USERS = [
    { name: 'Adani Group', img: 'assets/img/clients/adani.png' },
    { name: 'National Payments Corporation of India (NPCI)', img: 'assets/img/clients/npci.png' },
    { name: 'Air India', img: 'assets/img/clients/air-india.png' },
    { name: 'Lufthansa', img: 'assets/img/clients/lufthansa.png' },
    { name: 'Maharashtra Police', img: 'assets/img/clients/maharashtra-police.png' },
    { name: 'Bayer', img: 'assets/img/clients/bayer.png' },
    { name: 'IKEA', img: 'assets/img/clients/ikea.png' },
    { name: 'Vodafone', img: 'assets/img/clients/vodafone.png' },
    { name: 'Procter & Gamble', img: 'assets/img/clients/pg.png' },
    { name: 'H&M', img: 'assets/img/clients/hm.png' },
    { name: 'GVK', img: 'assets/img/clients/gvk.png' },
    { name: 'Total', img: 'assets/img/clients/total.png' },
    { name: 'Otto', img: 'assets/img/clients/otto.png' },
    { name: 'Aldi Süd', img: 'assets/img/clients/aldi-sud.png' },
    { name: 'BVG', img: 'assets/img/about/users/bvg.png' },
    { name: 'Mibrag', img: 'assets/img/about/users/mibrag.png' },
    { name: 'Netto', img: 'assets/img/about/users/netto.png' },
    { name: 'Penny', img: 'assets/img/about/users/penny.png' },
    { name: "McDonald's", img: 'assets/img/about/users/mcdonalds.png' },
    { name: 'Subway', img: 'assets/img/about/users/subway.png' },
    { name: 'KFC', img: 'assets/img/about/users/kfc.png' },
    { name: 'Vivantes', img: 'assets/img/about/users/vivantes.png' },
    { name: 'Vamed', img: 'assets/img/about/users/vamed.png' },
    { name: 'Berlin.de', img: 'assets/img/about/users/berlin-de.png' },
    { name: 'T-Online', img: 'assets/img/about/users/t-online.png' },
    { name: 'AMG', img: 'assets/img/about/users/amg.png' },
    { name: 'DNA', img: 'assets/img/about/users/dna.png' },
    { name: 'SIBB', img: 'assets/img/about/users/sibb.png' },
    { name: 'E-Plus', img: 'assets/img/about/users/e-plus.png' },
    { name: 'Punjab Kesari', img: 'assets/img/about/users/punjab-kesari.png' },
    { name: 'KSA', img: 'assets/img/about/users/ksa.png' },
    { name: 'LBB', img: 'assets/img/about/users/lbb.png' }
  ];

  /* ------------------------------------------------------------------------
     5. RENDER DYNAMIC GRIDS & FULL BIO MODAL
     ------------------------------------------------------------------------ */
  const bioModalEl = document.getElementById('v3BioModal');
  const bioModal = bioModalEl ? new bootstrap.Modal(bioModalEl) : null;
  const bioAvatar = document.getElementById('v3BioAvatar');
  const bioName = document.getElementById('v3BioName');
  const bioRole = document.getElementById('v3BioRole');
  const bioBody = document.getElementById('v3BioBody');

  function openBioModal(person) {
    if (!bioModal || !person) return;
    if (bioAvatar) {
      bioAvatar.src = person.img;
      bioAvatar.alt = person.name;
    }
    if (bioName) bioName.textContent = person.name;
    if (bioRole) bioRole.textContent = person.role;
    if (bioBody) {
      bioBody.innerHTML = person.bio.map((p) => `<p class="mb-3">${p}</p>`).join('');
    }
    bioModal.show();
  }

  function renderGrids() {
    // Executive Team Grid
    const execGrid = document.getElementById('v3ExecGrid');
    if (execGrid) {
      execGrid.innerHTML = EXECUTIVE_TEAM.map(
        (m, idx) => `
        <div class="col-sm-6 col-lg-4 col-xl-3 v3-stagger">
          <article class="v3-exec-card">
            <div class="v3-exec-photo">
              <img src="${m.img}" alt="${m.name}" loading="lazy" />
            </div>
            <div class="v3-exec-body">
              <div>
                <h3 class="v3-exec-name">${m.name}</h3>
                <div class="v3-exec-role">${m.role}</div>
                <p class="v3-exec-bio">${m.bio[0]}</p>
              </div>
              <button type="button" class="v3-read-bio-btn" data-bio-group="exec" data-bio-idx="${idx}">
                Read Full Bio <i class="bi bi-arrow-right"></i>
              </button>
            </div>
          </article>
        </div>`
      ).join('');
    }

    // Advisors Grid
    const advGrid = document.getElementById('v3AdvisorGrid');
    if (advGrid) {
      advGrid.innerHTML = ADVISORS.map(
        (a, idx) => `
        <div class="col-md-6 col-lg-4 v3-stagger">
          <article class="v3-advisor-card">
            <div>
              <div class="v3-advisor-head">
                <div class="v3-advisor-avatar">
                  <img src="${a.img}" alt="${a.name}" loading="lazy" />
                </div>
                <div>
                  <h3 class="h6 text-white fw-semibold mb-1">${a.name}</h3>
                  <div class="small fw-medium" style="color: var(--v3-orange-bright); font-size: 0.76rem;">${a.role}</div>
                </div>
              </div>
              <p class="v3-advisor-bio">${a.bio[0]}</p>
            </div>
            <button type="button" class="v3-read-bio-dark" data-bio-group="advisor" data-bio-idx="${idx}">
              Read Full Bio <i class="bi bi-arrow-right"></i>
            </button>
          </article>
        </div>`
      ).join('');
    }

    // Alliance Partners Grid
    const partnerGrid = document.getElementById('v3PartnerGrid');
    if (partnerGrid) {
      partnerGrid.innerHTML = PARTNERS.map(
        (p) => `
        <div class="col v3-stagger">
          <div class="v3-partner-tile">
            <div class="v3-partner-logo-box">
              <img src="${p.img}" alt="${p.name}" loading="lazy" />
            </div>
            <div class="v3-partner-name">${p.name}</div>
          </div>
        </div>`
      ).join('');
    }

    // Users / Customers Logo Grid
    const usersGrid = document.getElementById('v3UsersGrid');
    if (usersGrid) {
      usersGrid.innerHTML = USERS.map(
        (u) => `
        <div class="col v3-stagger">
          <div class="v3-user-logo-card" title="${u.name}">
            <img src="${u.img}" alt="${u.name}" loading="lazy" />
          </div>
        </div>`
      ).join('');
    }

    // Bind full bio modal clicks
    document.querySelectorAll('[data-bio-group]').forEach((btn) => {
      btn.addEventListener('click', () => {
        const grp = btn.dataset.bioGroup;
        const idx = Number(btn.dataset.bioIdx);
        const list = grp === 'exec' ? EXECUTIVE_TEAM : ADVISORS;
        openBioModal(list[idx]);
      });
    });
  }

  /* ------------------------------------------------------------------------
     6. FORMS & ACTIVE PILL NAV TRACKING
     ------------------------------------------------------------------------ */
  const demoForm = document.getElementById('v3DemoForm');
  const demoOk = document.getElementById('v3DemoOk');
  if (demoForm) {
    demoForm.addEventListener('submit', (e) => {
      e.preventDefault();
      if (!demoForm.checkValidity()) {
        demoForm.classList.add('was-validated');
        return;
      }
      if (demoOk) demoOk.classList.remove('d-none');
      demoForm.classList.remove('was-validated');
      demoForm.reset();
    });
  }

  const newsForm = document.getElementById('v3NewsletterForm');
  const newsOk = document.getElementById('v3NewsOk');
  if (newsForm) {
    newsForm.addEventListener('submit', (e) => {
      e.preventDefault();
      if (newsOk) newsOk.classList.remove('d-none');
      newsForm.reset();
    });
  }

  // Active nav highlight for About sections
  const navLinks = document.querySelectorAll('.v3-nav-links a[href^="#"]');
  const trackedSecs = document.querySelectorAll('section[id]');
  if ('IntersectionObserver' in window) {
    const navObs = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            const id = entry.target.getAttribute('id');
            navLinks.forEach((a) => a.classList.toggle('active', a.getAttribute('href') === '#' + id));
          }
        });
      },
      { rootMargin: '-32% 0px -56% 0px' }
    );
    trackedSecs.forEach((s) => navObs.observe(s));
  }

  /* ------------------------------------------------------------------------
     7. EXACT SAME GSAP + SCROLLTRIGGER ANIMATIONS AS index3.html
     ------------------------------------------------------------------------ */
  function splitWordsForReveal() {
    document.querySelectorAll('[data-word-reveal]').forEach((heading) => {
      const text = heading.textContent.trim();
      const words = text.split(/\s+/);
      heading.innerHTML = words.map((w) => `<span class="wr-word">${w}</span>`).join(' ');
    });
  }

  function initScrollAnimations() {
    if (typeof gsap === 'undefined' || typeof ScrollTrigger === 'undefined' || prefersReducedMotion) {
      const fill = document.getElementById('v3TimelineFill');
      if (fill) fill.style.height = '100%';
      document.querySelectorAll('.v3-timeline-item').forEach((el) => el.classList.add('is-lit'));
      return;
    }

    gsap.registerPlugin(ScrollTrigger);

    // Hero Stagger Entrance (Identical to index3)
    gsap.from('.v3-hero-stagger', {
      y: 26,
      opacity: 0,
      duration: 0.72,
      stagger: 0.1,
      ease: 'power3.out'
    });

    // Word-by-word Luminance Reveals (Identical to index3)
    document.querySelectorAll('[data-word-reveal]').forEach((heading) => {
      const mode = heading.dataset.wordReveal;
      const words = heading.querySelectorAll('.wr-word');
      if (!words.length) return;

      const isHero = heading.closest('#company') !== null;

      if (isHero) {
        gsap.fromTo(
          words,
          { color: 'rgba(255,255,255,0.2)', y: 14 },
          { color: '#ffffff', y: 0, duration: 0.7, stagger: 0.08, ease: 'power3.out' }
        );
      } else {
        gsap.fromTo(
          words,
          { color: mode === 'dark' ? 'rgba(255,255,255,0.2)' : '#d1d5dc', y: 12 },
          {
            color: mode === 'dark' ? '#ffffff' : '#0a0a0e',
            y: 0,
            stagger: 0.08,
            ease: 'power2.out',
            scrollTrigger: {
              trigger: heading,
              start: 'top 84%',
              end: 'top 44%',
              scrub: 0.6
            }
          }
        );
      }
    });

    // Standard Section Reveals (Identical to index3)
    gsap.utils.toArray('.v3-reveal').forEach((el) => {
      gsap.from(el, {
        y: 30,
        opacity: 0,
        duration: 0.78,
        ease: 'power3.out',
        scrollTrigger: { trigger: el, start: 'top 86%', once: true }
      });
    });

    // Staggered Grids (Identical to index3)
    document.querySelectorAll('.row').forEach((row) => {
      const items = row.querySelectorAll(':scope > .v3-stagger');
      if (!items.length) return;
      gsap.from(items, {
        y: 28,
        opacity: 0,
        duration: 0.68,
        stagger: 0.055,
        ease: 'power3.out',
        scrollTrigger: { trigger: row, start: 'top 86%', once: true }
      });
    });

    // History Scroll-Scrubbed Progress Rail & Node Illumination
    const timelineWrap = document.getElementById('v3HistoryTimeline');
    const timelineFill = document.getElementById('v3TimelineFill');
    const timelineItems = document.querySelectorAll('.v3-timeline-item');

    if (timelineWrap && timelineFill) {
      gsap.to(timelineFill, {
        height: '100%',
        ease: 'none',
        scrollTrigger: {
          trigger: timelineWrap,
          start: 'top 68%',
          end: 'bottom 60%',
          scrub: 0.5
        }
      });

      timelineItems.forEach((item) => {
        ScrollTrigger.create({
          trigger: item,
          start: 'top 68%',
          onEnter: () => item.classList.add('is-lit'),
          onLeaveBack: () => item.classList.remove('is-lit')
        });
      });
    }
  }

  window.addEventListener('load', () => {
    renderGrids();
    splitWordsForReveal();
    initScrollAnimations();
    if (document.fonts && document.fonts.ready && typeof ScrollTrigger !== 'undefined') {
      document.fonts.ready.then(() => ScrollTrigger.refresh());
    }
  });
})();
