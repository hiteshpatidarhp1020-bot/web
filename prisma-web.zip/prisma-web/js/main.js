/* ==========================================================================
   PRISMA AI — INTERACTIVE EXPERIENCE & SCROLL CHOREOGRAPHY
   Vanilla JS + GSAP 3 + ScrollTrigger
   ========================================================================== */

(function () {
  'use strict';

  const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  /* ------------------------------------------------------------------------
     1. DATA MODELS (100% Authentic Prisma AI Content)
     ------------------------------------------------------------------------ */
  const GRYPHOS_CHAPTERS = [
    {
      code: 'GRYPHOS // MODULE 01',
      category: 'VISUAL RECOGNITION ENGINES',
      icon: 'bi-eye',
      title: 'Multi-Input Visual Perception',
      summary:
        'Processes live camera feeds, archived video streams, documents, and X-ray imagery through unified deep neural pipelines.',
      chips: [
        { label: 'Face Recognition', active: true },
        { label: 'Object Recognition', active: true },
        { label: 'Image Recognition', active: false },
        { label: 'OCR', active: false },
        { label: 'Body Pose Estimation', active: false }
      ],
      metrics: [
        { val: '5 Core', key: 'Vision Engines' },
        { val: 'Real-Time', key: 'Stream Inference' },
        { val: 'DCNN', key: 'Architecture' }
      ]
    },
    {
      code: 'GRYPHOS // MODULE 02',
      category: '230+ PRE-TRAINED AI APIs',
      icon: 'bi-boxes',
      title: 'Web Dashboard for Every API Engine',
      summary:
        'Plug in modular AI engines on demand and review structured analytics, searchable archives, and visual verifications through a unified portal.',
      chips: [
        { label: 'Special Assistance', active: true },
        { label: 'Lost Bag Video Search', active: true },
        { label: 'Face Boarding Pass', active: true },
        { label: 'AI X-Ray Analysis', active: false },
        { label: 'Supply Chain Tracking', active: false }
      ],
      metrics: [
        { val: '230+', key: 'Ready APIs' },
        { val: 'Unified', key: 'Web Portal' },
        { val: 'Modular', key: 'Plug-In Design' }
      ]
    },
    {
      code: 'GRYPHOS // MODULE 03',
      category: 'COGNITIVE INTELLIGENCE',
      icon: 'bi-cpu',
      title: 'Predictive Behavioral & Sentiment Analysis',
      summary:
        'Creates a second language to interpret human body language, gestures, facial expressions, and crowd anomalies with continuous self-learning.',
      chips: [
        { label: 'Body Behavior', active: true },
        { label: 'Facial Sentiment', active: true },
        { label: 'Gesture Signals', active: true },
        { label: 'Crowd Density', active: false },
        { label: 'Self-Learning', active: false }
      ],
      metrics: [
        { val: '99%+', key: 'Match Accuracy' },
        { val: 'Active ML', key: 'Self-Learning' },
        { val: 'Predictive', key: 'Cognitive Layer' }
      ]
    },
    {
      code: 'GRYPHOS // MODULE 04',
      category: 'DECISION SCIENCE & DEPLOYMENT',
      icon: 'bi-broadcast',
      title: 'Autonomous Real-Time Triggers Everywhere',
      summary:
        'Deploys directly onto client on-premise servers or private cloud, dispatching instant multi-device alerts across existing networks.',
      chips: [
        { label: 'On-Premise Ready', active: true },
        { label: 'Private Cloud', active: true },
        { label: 'Instant Push Alerts', active: true },
        { label: 'Zero Rewiring', active: false },
        { label: 'Enterprise Scale', active: false }
      ],
      metrics: [
        { val: 'Weeks', key: 'To Production' },
        { val: 'On-Prem', key: 'Data Sovereignty' },
        { val: '24/7', key: 'Alert Triggers' }
      ]
    }
  ];

  const INDUSTRIES_DATA = {
    aviation: {
      badge: 'SECTOR // AVIATION',
      title: 'Aviation & Airport Operations',
      desc: 'Streamline passenger throughput and elevate terminal vigilance with contactless face-as-boarding-pass gates, unattended baggage alerts, and proactive assistance for special-needs travelers.',
      img: 'assets/img/visuals/industry-aviation.jpg',
      alt: 'Modern international airport corridor with biometric e-gates',
      caps: [
        'Face-as-boarding-pass for walk-through access',
        'Alert for unattended bag or purse',
        'Identification of lost bags from video archives',
        'Providing assistance to special individuals & elderly',
        'Advanced AI X-Ray prohibited object detection',
        'Real-time customs & passenger profiling'
      ]
    },
    banking: {
      badge: 'SECTOR // BANKING & FINANCE',
      title: 'Banking & Financial Institutions',
      desc: 'Strengthen branch and digital transaction security with biometric facial authentication, suspicious behavior monitoring, and attentive customer assistance tracking.',
      img: 'assets/img/visuals/industry-security.jpg',
      alt: 'High-security enterprise financial access control corridor',
      caps: [
        'Face-recognition-based financial transactions',
        'Illegal object & weapon detection in branches',
        'Suspicious behavior real-time alerts',
        'Bank vault biometric protection & access control',
        'Identification of lost bags & unattended items',
        'Automated attendance & elderly customer assistance'
      ]
    },
    infrastructure: {
      badge: 'SECTOR // INFRASTRUCTURE',
      title: 'Smart Highways & Traffic Automation',
      desc: 'Transform highway CCTV into autonomous traffic enforcement and tolling intelligence with high-speed Automatic Number Plate Recognition (ANPR) and incident detection.',
      img: 'assets/img/visuals/industry-infrastructure.jpg',
      alt: 'Smart European highway ANPR sensor gantry at night',
      caps: [
        'Automated ticketing for red-light violations',
        'Ticketing for speed & reckless driving violations',
        'Seamless toll collection through license plates',
        'Real-time highway accident alerts',
        'Smart parking management & license tracking',
        '24/7 multi-lane CCTV traffic analytics'
      ]
    },
    security: {
      badge: 'SECTOR // ENTERPRISE SECURITY',
      title: 'Public & Restricted Space Security',
      desc: 'Empower command centers with proactive visual surveillance — detecting hazardous objects, banned individuals, crowd incidents, and perimeter intrusions in real time.',
      img: 'assets/img/visuals/industry-security.jpg',
      alt: 'Modern high-security data center and biometric access turnstiles',
      caps: [
        'Incident detection in high-density crowds',
        'Crowd sentiment & anomaly analysis',
        'Hazardous & prohibited object detection',
        'Facial authentication for restricted entry',
        'Instant banned-person & repeat-offender alerts',
        'Suspicious behavior & intrusion monitoring'
      ]
    },
    education: {
      badge: 'SECTOR // EDUCATION & EXAMS',
      title: 'Education & Examination Centers',
      desc: 'Guarantee exam integrity across thousands of testing facilities with candidate identity verification, suspicious eye/body movement monitoring, and automated assessment workflows.',
      img: 'assets/img/visuals/hero-optics.jpg',
      alt: 'Precision optical intelligence lens for exam monitoring',
      caps: [
        'Candidate identity verification against impersonation',
        'Suspicious activity detection via body movements',
        'Suspicious activity detection via eye movements',
        'Detection of banned objects in exam halls',
        'Student sentiment & engagement analysis',
        'Automated paper corrections & attendance'
      ]
    },
    events: {
      badge: 'SECTOR // EVENTS & VENUES',
      title: 'Large-Scale Events & Public Gatherings',
      desc: 'Deliver seamless contactless entry and real-time crowd safety for stadiums, exhibitions, and pilgrimage centers using face-as-a-ticket and live density dashboards.',
      img: 'assets/img/visuals/industry-aviation.jpg',
      alt: 'High-throughput contactless biometric access gates',
      caps: [
        'Face-as-a-ticket contactless venue entry',
        'Real-time crowd density & people counting',
        'Smart venue parking management system',
        'Crowd sentiment & safety incident alerts',
        'VIP & special individual tracking for assistance',
        'Banned individual & watchlist notifications'
      ]
    },
    manufacturing: {
      badge: 'SECTOR // MANUFACTURING',
      title: 'Smart Manufacturing & Industrial Plants',
      desc: 'Protect workforce safety and production uptime with automated PPE safety-gear verification, visual defect alerts, predictive maintenance, and supply chain tracking.',
      img: 'assets/img/visuals/industry-infrastructure.jpg',
      alt: 'Industrial smart infrastructure and optical monitoring',
      caps: [
        'Automated detection of mandatory safety gear (PPE)',
        'Real-time visual alerts on product defect detection',
        'Predictive maintenance & equipment monitoring',
        'Face recognition for restricted floor entry',
        'Supply chain box, pallet & attendant tracking',
        'Automated plant attendance & shift logging'
      ]
    }
  };

  /* ------------------------------------------------------------------------
     2. NAVBAR, SCROLL PROGRESS BAR & BACK TO TOP
     ------------------------------------------------------------------------ */
  const navbar = document.getElementById('mainNavbar');
  const progressBar = document.getElementById('scrollProgressBar');
  const backToTop = document.getElementById('backToTop');
  const navLinks = document.querySelectorAll('.prisma-navbar .nav-link[href^="#"]');
  const navbarCollapse = document.getElementById('navbarContent');

  function handleScrollChrome() {
    const scrollTop = window.scrollY || document.documentElement.scrollTop;
    const docHeight = document.documentElement.scrollHeight - window.innerHeight;
    const pct = docHeight > 0 ? (scrollTop / docHeight) * 100 : 0;

    if (progressBar) progressBar.style.width = pct.toFixed(2) + '%';
    if (navbar) navbar.classList.toggle('scrolled', scrollTop > 40);
    if (backToTop) backToTop.classList.toggle('visible', scrollTop > 600);
  }

  window.addEventListener('scroll', handleScrollChrome, { passive: true });
  handleScrollChrome();

  if (backToTop) {
    backToTop.addEventListener('click', () => {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    });
  }

  // Close mobile collapse menu when clicking an anchor link
  navLinks.forEach((link) => {
    link.addEventListener('click', () => {
      if (navbarCollapse && navbarCollapse.classList.contains('show')) {
        const bsCollapse = bootstrap.Collapse.getInstance(navbarCollapse);
        if (bsCollapse) bsCollapse.hide();
      }
    });
  });

  // Active nav highlight via IntersectionObserver
  const trackedSections = document.querySelectorAll('section[id], div[id="global"]');
  if ('IntersectionObserver' in window) {
    const navObserver = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            const id = entry.target.getAttribute('id');
            navLinks.forEach((l) => {
              l.classList.toggle('active', l.getAttribute('href') === '#' + id);
            });
          }
        });
      },
      { rootMargin: '-38% 0px -52% 0px' }
    );
    trackedSections.forEach((sec) => navObserver.observe(sec));
  }

  /* ------------------------------------------------------------------------
     3. PRODUCT SUITE TABS & DEMO PREFILL
     ------------------------------------------------------------------------ */
  const productButtons = document.querySelectorAll('.product-tab-btn');
  const productPanels = document.querySelectorAll('.product-panel');

  function activateProductTab(productKey) {
    productButtons.forEach((btn) => {
      const isMatch = btn.dataset.product === productKey;
      btn.classList.toggle('active', isMatch);
      btn.setAttribute('aria-selected', isMatch ? 'true' : 'false');
    });
    productPanels.forEach((panel) => {
      panel.classList.toggle('active', panel.id === 'panel-' + productKey);
    });
  }

  productButtons.forEach((btn) => {
    btn.addEventListener('click', () => activateProductTab(btn.dataset.product));
  });

  // Footer product jump links activate matching product tab
  document.querySelectorAll('[data-jump-product]').forEach((link) => {
    link.addEventListener('click', () => {
      activateProductTab(link.dataset.jumpProduct);
    });
  });

  // "Request [Product] Demo" pre-fills form dropdown & scrolls smoothly
  const demoSelect = document.getElementById('demoProduct');
  document.querySelectorAll('.demo-prefill-btn').forEach((btn) => {
    btn.addEventListener('click', () => {
      const targetProd = btn.dataset.demoProduct;
      if (demoSelect && targetProd) {
        demoSelect.value = targetProd;
      }
      const demoSec = document.getElementById('demo');
      if (demoSec) {
        demoSec.scrollIntoView({ behavior: 'smooth' });
      }
    });
  });

  /* ------------------------------------------------------------------------
     4. INTERACTIVE 7-INDUSTRY EXPLORER
     ------------------------------------------------------------------------ */
  const industryButtons = document.querySelectorAll('.industry-btn');
  const indImg = document.getElementById('industryVisualImg');
  const indBadge = document.getElementById('industryBadge');
  const indTitle = document.getElementById('industryTitle');
  const indDesc = document.getElementById('industryDesc');
  const indCapList = document.getElementById('industryCapList');
  const indPanel = document.getElementById('industryDetailPanel');

  function renderIndustry(key) {
    const data = INDUSTRIES_DATA[key];
    if (!data) return;

    industryButtons.forEach((btn) => {
      btn.classList.toggle('active', btn.dataset.industry === key);
    });

    if (indPanel && !prefersReducedMotion && typeof gsap !== 'undefined') {
      gsap.fromTo(
        indPanel,
        { opacity: 0.72, y: 8 },
        { opacity: 1, y: 0, duration: 0.35, ease: 'power2.out' }
      );
    }

    if (indImg) {
      indImg.src = data.img;
      indImg.alt = data.alt;
    }
    if (indBadge) indBadge.textContent = data.badge;
    if (indTitle) indTitle.textContent = data.title;
    if (indDesc) indDesc.textContent = data.desc;
    if (indCapList) {
      indCapList.innerHTML = data.caps
        .map((cap) => `<li><i class="bi bi-check2"></i> ${cap}</li>`)
        .join('');
    }
  }

  industryButtons.forEach((btn) => {
    btn.addEventListener('click', () => renderIndustry(btn.dataset.industry));
  });

  /* ------------------------------------------------------------------------
     5. GRYPHOS CONSOLE STATE UPDATER (SYNCED WITH PINNED SCROLL)
     ------------------------------------------------------------------------ */
  const consoleStageCode = document.getElementById('consoleStageCode');
  const consoleCategory = document.getElementById('consoleCategory');
  const consoleIcon = document.getElementById('consoleIcon');
  const consoleTitle = document.getElementById('consoleTitle');
  const consoleSummary = document.getElementById('consoleSummary');
  const consoleChips = document.getElementById('consoleChips');
  const consoleMetrics = document.getElementById('consoleMetrics');
  const railSegments = document.querySelectorAll('.rail-segment');
  const chapterCards = document.querySelectorAll('.gryphos-chapter');
  let activeChapterIdx = -1;

  function setGryphosStage(idx) {
    if (idx === activeChapterIdx || !GRYPHOS_CHAPTERS[idx]) return;
    activeChapterIdx = idx;
    const data = GRYPHOS_CHAPTERS[idx];

    chapterCards.forEach((card, i) => {
      card.classList.toggle('is-active', i === idx);
    });

    railSegments.forEach((seg, i) => {
      seg.classList.toggle('is-active', i === idx);
      seg.classList.toggle('is-done', i < idx);
    });

    const stageFrame = document.querySelector('.stage-visual-frame');
    if (stageFrame && !prefersReducedMotion && typeof gsap !== 'undefined') {
      gsap.fromTo(
        stageFrame,
        { opacity: 0.45, y: 10 },
        { opacity: 1, y: 0, duration: 0.36, ease: 'power2.out' }
      );
    }

    if (consoleStageCode) consoleStageCode.textContent = data.code;
    if (consoleCategory) consoleCategory.textContent = data.category;
    if (consoleIcon) consoleIcon.className = `bi ${data.icon} text-white-50`;
    if (consoleTitle) consoleTitle.textContent = data.title;
    if (consoleSummary) consoleSummary.textContent = data.summary;

    if (consoleChips) {
      consoleChips.innerHTML = data.chips
        .map((c) => `<span class="stage-chip${c.active ? ' active' : ''}">${c.label}</span>`)
        .join('');
    }

    if (consoleMetrics) {
      consoleMetrics.innerHTML = data.metrics
        .map(
          (m) => `
          <div>
            <div class="stage-metric-val">${m.val}</div>
            <div class="stage-metric-key">${m.key}</div>
          </div>`
        )
        .join('');
    }
  }

  // Allow clicking chapters directly to inspect stage
  chapterCards.forEach((card, i) => {
    card.addEventListener('click', () => setGryphosStage(i));
  });

  /* ------------------------------------------------------------------------
     6. REQUEST A DEMO FORM VALIDATION & SUBMISSION
     ------------------------------------------------------------------------ */
  const demoForm = document.getElementById('demoRequestForm');
  const demoSuccessMsg = document.getElementById('demoSuccessMsg');
  const confirmedProduct = document.getElementById('confirmedProduct');

  if (demoForm) {
    demoForm.addEventListener('submit', (e) => {
      e.preventDefault();
      if (!demoForm.checkValidity()) {
        demoForm.classList.add('was-validated');
        return;
      }

      const selectedProd = demoSelect ? demoSelect.value : 'Gryphos Platform';
      if (confirmedProduct) confirmedProduct.textContent = selectedProd;
      if (demoSuccessMsg) {
        demoSuccessMsg.classList.remove('d-none');
        demoSuccessMsg.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
      }

      demoForm.classList.remove('was-validated');
      demoForm.reset();
    });
  }

  /* ------------------------------------------------------------------------
     7. GSAP + SCROLLTRIGGER ADVANCED SCROLL CHOREOGRAPHY
     ------------------------------------------------------------------------ */
  function initScrollAnimations() {
    if (typeof gsap === 'undefined' || typeof ScrollTrigger === 'undefined') {
      // Graceful fallback if CDN blocked
      document.querySelectorAll('.counter').forEach((el) => {
        el.textContent = Number(el.dataset.target).toLocaleString();
      });
      document.querySelectorAll('.pipeline-step-card').forEach((c) => c.classList.add('is-lit'));
      return;
    }

    gsap.registerPlugin(ScrollTrigger);

    if (prefersReducedMotion) {
      document.querySelectorAll('.counter').forEach((el) => {
        el.textContent = Number(el.dataset.target).toLocaleString();
      });
      document.querySelectorAll('.pipeline-step-card').forEach((c) => c.classList.add('is-lit'));
      const line = document.getElementById('pipelineLineFill');
      if (line) line.style.width = '100%';
      return;
    }

    // A) Hero Entrance Sequence
    const heroTl = gsap.timeline({ defaults: { ease: 'power3.out' } });
    heroTl
      .from('.hero-reveal', {
        y: 28,
        opacity: 0,
        duration: 0.78,
        stagger: 0.1
      })
      .from(
        '.hero-visual-reveal',
        {
          y: 34,
          opacity: 0,
          scale: 0.97,
          duration: 0.9
        },
        '-=0.55'
      )
      .from(
        '.hero-pillar-reveal',
        {
          y: 20,
          opacity: 0,
          duration: 0.65,
          stagger: 0.08
        },
        '-=0.45'
      );

    // B) Subtle Parallax on Hero Optical Image
    const heroImg = document.getElementById('heroParallaxImg');
    if (heroImg) {
      gsap.to(heroImg, {
        yPercent: 10,
        scale: 1.09,
        ease: 'none',
        scrollTrigger: {
          trigger: '.hero-section',
          start: 'top top',
          end: 'bottom top',
          scrub: true
        }
      });
    }

    // C) Animated Impact Counters
    document.querySelectorAll('.counter').forEach((el) => {
      const target = Number(el.dataset.target || 0);
      const obj = { val: 0 };
      ScrollTrigger.create({
        trigger: el,
        start: 'top 88%',
        once: true,
        onEnter: () => {
          gsap.to(obj, {
            val: target,
            duration: 1.45,
            ease: 'power2.out',
            onUpdate: () => {
              el.textContent = Math.round(obj.val).toLocaleString();
            }
          });
        }
      });
    });

    // D) Smooth Section Heading & Block Reveals
    gsap.utils.toArray('.reveal-up').forEach((elem) => {
      gsap.from(elem, {
        y: 32,
        opacity: 0,
        duration: 0.78,
        ease: 'power3.out',
        scrollTrigger: {
          trigger: elem,
          start: 'top 86%',
          once: true
        }
      });
    });

    // E) Staggered Grids & Cards (Grouped by Parent Row)
    document.querySelectorAll('.row').forEach((row) => {
      const items = row.querySelectorAll(':scope > .stagger-item');
      if (!items.length) return;
      gsap.from(items, {
        y: 30,
        opacity: 0,
        duration: 0.72,
        stagger: 0.09,
        ease: 'power3.out',
        scrollTrigger: {
          trigger: row,
          start: 'top 84%',
          once: true
        }
      });
    });

    // F) RESPONSIVE PINNED STORYTELLING SECTIONS (Desktop >= 992px)
    const mm = gsap.matchMedia();

    mm.add('(min-width: 992px)', () => {
      // SIGNATURE PIN #1: Gryphos Console pins inside col-lg-5 while right chapters scroll & drive console state
      const consoleEl = document.getElementById('gryphosConsole');
      const chaptersWrap = document.getElementById('gryphosChapters');

      if (consoleEl && chaptersWrap) {
        ScrollTrigger.create({
          trigger: '#gryphosPinSection',
          start: 'top 108px',
          end: () => '+=' + Math.max(120, chaptersWrap.offsetHeight - consoleEl.offsetHeight),
          pin: consoleEl,
          pinSpacing: false,
          invalidateOnRefresh: true
        });
      }

      chapterCards.forEach((card, idx) => {
        ScrollTrigger.create({
          trigger: card,
          start: 'top 56%',
          end: 'bottom 44%',
          onEnter: () => setGryphosStage(idx),
          onEnterBack: () => setGryphosStage(idx)
        });
      });

      // SIGNATURE PIN #2: Deployment Pipeline pins smoothly & scrubs across all 4 stages
      const pipelinePin = document.getElementById('deploymentPinTarget');
      const lineFill = document.getElementById('pipelineLineFill');
      const stepCards = document.querySelectorAll('.pipeline-step-card');
      const statusLabel = document.getElementById('pipelineStatusLabel');
      const stageNames = [
        'STAGE 01 OF 04 — DEFINE SCOPE',
        'STAGE 02 OF 04 — SELECT APIS',
        'STAGE 03 OF 04 — START POC',
        'STAGE 04 OF 04 — DEPLOYMENT'
      ];

      if (pipelinePin && lineFill && stepCards.length) {
        const pipeTl = gsap.timeline({
          scrollTrigger: {
            trigger: '#deployment',
            start: 'top top',
            end: '+=1500',
            pin: true,
            scrub: 0.65,
            anticipatePin: 1,
            onUpdate: (self) => {
              const p = self.progress;
              const activeStep = Math.min(3, Math.floor(p * 4));
              stepCards.forEach((card, idx) => {
                card.classList.toggle('is-lit', idx <= activeStep);
              });
              if (statusLabel) {
                statusLabel.textContent = stageNames[activeStep];
              }
            }
          }
        });

        pipeTl.to(lineFill, {
          width: '100%',
          ease: 'none',
          duration: 1
        });
      }
    });

    // Mobile & Tablet graceful scroll activation (no pinning)
    mm.add('(max-width: 991.98px)', () => {
      chapterCards.forEach((card, idx) => {
        ScrollTrigger.create({
          trigger: card,
          start: 'top 72%',
          onEnter: () => setGryphosStage(idx),
          onEnterBack: () => setGryphosStage(idx)
        });
      });

      document.querySelectorAll('.pipeline-step-card').forEach((card) => {
        ScrollTrigger.create({
          trigger: card,
          start: 'top 80%',
          once: true,
          onEnter: () => card.classList.add('is-lit')
        });
      });
    });
  }

  window.addEventListener('load', () => {
    setGryphosStage(0);
    initScrollAnimations();
    if (document.fonts && document.fonts.ready && typeof ScrollTrigger !== 'undefined') {
      document.fonts.ready.then(() => ScrollTrigger.refresh());
    }
  });
})();
