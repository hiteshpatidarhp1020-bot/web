/* ==========================================================================
   PRISMA AI — CORE ALGORITHM PAGE ANIMATIONS (INDEX3 DESIGN SYSTEM)
   Vanilla JS + GSAP 3 + ScrollTrigger
   ========================================================================== */

(function () {
  'use strict';

  const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  /* ------------------------------------------------------------------------
     1. DEMO FORM & NEWSLETTER VALIDATION
     ------------------------------------------------------------------------ */
  const demoForm = document.getElementById('v3DemoForm');
  const demoOk = document.getElementById('v3DemoOk');
  if (demoForm) {
    demoForm.addEventListener('submit', (e) => {
      e.preventDefault();
      if (!demoForm.checkValidity()) {
        demoForm.classList.add('was-validated');
        return;
      }
      if (demoOk) demoOk.classList.remove('d-none');
      demoForm.classList.remove('was-validated');
      demoForm.reset();
    });
  }

  const newsForm = document.getElementById('v3NewsletterForm');
  const newsOk = document.getElementById('v3NewsOk');
  if (newsForm) {
    newsForm.addEventListener('submit', (e) => {
      e.preventDefault();
      if (newsOk) newsOk.classList.remove('d-none');
      newsForm.reset();
    });
  }

  /* ------------------------------------------------------------------------
     2. EXACT SAME GSAP + SCROLLTRIGGER ANIMATIONS AS index3.html
     ------------------------------------------------------------------------ */
  function splitWordsForReveal() {
    document.querySelectorAll('[data-word-reveal]').forEach((heading) => {
      const text = heading.textContent.trim();
      const words = text.split(/\s+/);
      heading.innerHTML = words.map((w) => `<span class="wr-word">${w}</span>`).join(' ');
    });
  }

  function initScrollAnimations() {
    if (typeof gsap === 'undefined' || typeof ScrollTrigger === 'undefined' || prefersReducedMotion) {
      return;
    }

    gsap.registerPlugin(ScrollTrigger);

    // Hero Stagger Entrance
    gsap.from('.v3-hero-stagger', {
      y: 26,
      opacity: 0,
      duration: 0.72,
      stagger: 0.1,
      ease: 'power3.out'
    });

    // Word-by-word Luminance Reveals (Dark & Light Sections)
    document.querySelectorAll('[data-word-reveal]').forEach((heading) => {
      const mode = heading.dataset.wordReveal;
      const words = heading.querySelectorAll('.wr-word');
      if (!words.length) return;

      const isHero = heading.closest('#overview') !== null;

      if (isHero) {
        gsap.fromTo(
          words,
          { color: 'rgba(255,255,255,0.2)', y: 14 },
          { color: '#ffffff', y: 0, duration: 0.7, stagger: 0.08, ease: 'power3.out' }
        );
      } else {
        gsap.fromTo(
          words,
          { color: mode === 'dark' ? 'rgba(255,255,255,0.2)' : '#d1d5dc', y: 12 },
          {
            color: mode === 'dark' ? '#ffffff' : '#0a0a0e',
            y: 0,
            stagger: 0.08,
            ease: 'power2.out',
            scrollTrigger: {
              trigger: heading,
              start: 'top 84%',
              end: 'top 44%',
              scrub: 0.6
            }
          }
        );
      }
    });

    // Standard Reveals
    gsap.utils.toArray('.v3-reveal').forEach((el) => {
      gsap.from(el, {
        y: 30,
        opacity: 0,
        duration: 0.78,
        ease: 'power3.out',
        scrollTrigger: { trigger: el, start: 'top 86%', once: true }
      });
    });

    // Staggered Grids & Cards
    document.querySelectorAll('.row').forEach((row) => {
      const items = row.querySelectorAll(':scope > .v3-stagger');
      if (!items.length) return;
      gsap.from(items, {
        y: 28,
        opacity: 0,
        duration: 0.7,
        stagger: 0.075,
        ease: 'power3.out',
        scrollTrigger: { trigger: row, start: 'top 86%', once: true }
      });
    });
  }

  window.addEventListener('load', () => {
    splitWordsForReveal();
    initScrollAnimations();
    if (document.fonts && document.fonts.ready && typeof ScrollTrigger !== 'undefined') {
      document.fonts.ready.then(() => ScrollTrigger.refresh());
    }
  });
})();
